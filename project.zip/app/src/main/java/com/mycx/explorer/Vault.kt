package com.mycx.explorer

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class VItem(val file: File, val name: String, val size: Long)

object Vault {
    private val rnd = SecureRandom()

    fun dir(ctx: Context): File = File(ctx.filesDir, "vault").also { it.mkdirs() }
    private fun meta(ctx: Context): File = File(dir(ctx), ".meta")
    fun isSetUp(ctx: Context): Boolean = meta(ctx).exists()

    private fun derive(pin: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        val kb = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(kb, "AES")
    }

    private fun seal(k: SecretKeySpec, plain: ByteArray, len: Int, out: DataOutputStream) {
        val iv = ByteArray(12)
        rnd.nextBytes(iv)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, k, GCMParameterSpec(128, iv))
        val ct = c.doFinal(plain, 0, len)
        out.writeInt(ct.size)
        out.write(iv)
        out.write(ct)
    }

    private fun unseal(k: SecretKeySpec, inp: DataInputStream): ByteArray? {
        val n = try { inp.readInt() } catch (e: EOFException) { return null }
        if (n < 16 || n > 1_000_000) throw IOException("bad chunk")
        val iv = ByteArray(12)
        inp.readFully(iv)
        val ct = ByteArray(n)
        inp.readFully(ct)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, iv))
        return c.doFinal(ct)
    }

    fun setup(ctx: Context, pin: String): SecretKeySpec {
        val salt = ByteArray(16)
        rnd.nextBytes(salt)
        val k = derive(pin, salt)
        DataOutputStream(meta(ctx).outputStream().buffered()).use { o ->
            o.write(salt)
            val ok = "NMV".toByteArray()
            seal(k, ok, ok.size, o)
        }
        return k
    }

    fun unlock(ctx: Context, pin: String): SecretKeySpec? = try {
        DataInputStream(meta(ctx).inputStream().buffered()).use { i ->
            val salt = ByteArray(16)
            i.readFully(salt)
            val k = derive(pin, salt)
            val v = unseal(k, i)
            if (v != null && String(v) == "NMV") k else null
        }
    } catch (e: Exception) {
        null
    }

    fun add(ctx: Context, k: SecretKeySpec, src: File): Boolean = try {
        val out = File(dir(ctx), UUID.randomUUID().toString() + ".enc")
        DataOutputStream(out.outputStream().buffered()).use { o ->
            val nm = src.name.toByteArray()
            seal(k, nm, nm.size, o)
            src.inputStream().buffered().use { i ->
                val buf = ByteArray(65536)
                while (true) {
                    val n = i.read(buf)
                    if (n <= 0) break
                    seal(k, buf, n, o)
                }
            }
        }
        src.delete()
        true
    } catch (e: Exception) {
        false
    }

    fun list(ctx: Context, k: SecretKeySpec): List<VItem> =
        (dir(ctx).listFiles()?.toList() ?: emptyList()).filter { it.name.endsWith(".enc") }.mapNotNull { f ->
            try {
                DataInputStream(f.inputStream().buffered()).use { i ->
                    val nm = unseal(k, i)
                    if (nm == null) null else VItem(f, String(nm), f.length())
                }
            } catch (e: Exception) {
                null
            }
        }.sortedBy { it.name.lowercase() }

    fun export(k: SecretKeySpec, item: VItem, dst: File): Boolean = try {
        dst.parentFile?.mkdirs()
        DataInputStream(item.file.inputStream().buffered()).use { i ->
            unseal(k, i)
            dst.outputStream().buffered().use { o ->
                while (true) {
                    val d = unseal(k, i) ?: break
                    o.write(d)
                }
            }
        }
        true
    } catch (e: Exception) {
        false
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VaultScreen(nav: Nav) {
    val p = LocalP.current
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var menu by remember { mutableStateOf<VItem?>(null) }
    val setUp = remember(nav.tick, nav.vaultKey) { Vault.isSetUp(ctx) }
    val key = nav.vaultKey

    if (key == null) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Lock, null, tint = p.accent, modifier = Modifier.size(56.dp))
            Spacer(Modifier.height(14.dp))
            Text(if (setUp) S(R.string.s194) else S(R.string.s195), color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                if (setUp) S(R.string.s196) else S(R.string.s197),
                color = p.sub, fontSize = 13.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = pin, onValueChange = { pin = it.filter { c -> c.isDigit() }.take(8) }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                label = { Text("PIN") }
            )
            if (!setUp) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = pin2, onValueChange = { pin2 = it.filter { c -> c.isDigit() }.take(8) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    label = { Text(S(R.string.s198)) }
                )
            }
            val e = err
            if (e != null) {
                Spacer(Modifier.height(8.dp))
                Text(e, color = Color(0xFFE5484D), fontSize = 13.sp)
            }
            Spacer(Modifier.height(18.dp))
            Box(
                Modifier.neu(p, 22.dp).clip(RoundedCornerShape(22.dp)).clickable {
                    if (setUp) {
                        val k = Vault.unlock(ctx, pin)
                        if (k == null) {
                            err = S(R.string.s199)
                        } else {
                            err = null
                            pin = ""
                            nav.vaultKey = k
                            if (nav.pendingVault.isNotEmpty()) nav.addToVault(ctx, nav.pendingVault)
                        }
                    } else if (pin.length < 4) {
                        err = S(R.string.s200)
                    } else if (pin != pin2) {
                        err = S(R.string.s201)
                    } else {
                        val k = Vault.setup(ctx, pin)
                        err = null
                        pin = ""
                        pin2 = ""
                        nav.vaultKey = k
                        if (nav.pendingVault.isNotEmpty()) nav.addToVault(ctx, nav.pendingVault)
                    }
                }.padding(horizontal = 32.dp, vertical = 14.dp)
            ) { Text(if (setUp) S(R.string.s172) else S(R.string.s202), color = p.accent, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    } else {
        val items by produceState<List<VItem>?>(null, nav.tick, key) {
            value = withContext(Dispatchers.IO) { Vault.list(ctx, key) }
        }
        Column(Modifier.fillMaxSize().padding(start = 20.dp, end = 20.dp, top = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(S(R.string.s106), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                NeuBtn(Icons.Default.Lock, S(R.string.s203)) { nav.lockVault(ctx) }
            }
            val list = items
            if (list == null) {
                Box(Modifier.fillMaxSize(), Alignment.Center) { Text(S(R.string.s204), color = p.sub) }
            } else if (list.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), Alignment.Center) {
                    Text(
                        S(R.string.s205),
                        color = p.sub, textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(top = 14.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(list, key = { it.file.path }) { it2 ->
                        val kd = Fs.kindOf(it2.name, false)
                        Row(
                            Modifier.fillMaxWidth().neu(p, 18.dp).clip(RoundedCornerShape(18.dp))
                                .combinedClickable(
                                    onClick = {
                                        nav.status = S(R.string.s206)
                                        Thread {
                                            val dst = File(ctx.cacheDir, "vault/" + it2.name)
                                            if (Vault.export(key, it2, dst)) {
                                                Handler(Looper.getMainLooper()).post { nav.status = null; nav.open(ctx, dst, listOf(dst)) }
                                            } else {
                                                nav.flash(S(R.string.s207))
                                            }
                                        }.start()
                                    },
                                    onLongClick = { menu = it2 }
                                ).padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)).background(tint(kd)), contentAlignment = Alignment.Center) {
                                Icon(kindIcon(kd), null, tint = kindColor(kd))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(it2.name, color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(Fs.fmt(it2.size), color = p.sub, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
        val m = menu
        if (m != null) {
            AlertDialog(
                onDismissRequest = { menu = null },
                title = { Text(m.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                text = {
                    Column {
                        TextButton(onClick = {
                            menu = null
                            Thread {
                                val dst = Fs.unique(File(Fs.root, "Download"), m.name)
                                if (Vault.export(key, m, dst)) {
                                    m.file.delete()
                                    nav.tick++
                                    nav.flash(S(R.string.s208))
                                } else {
                                    nav.flash(S(R.string.s207))
                                }
                            }.start()
                        }) { Text(S(R.string.s209)) }
                        TextButton(onClick = { m.file.delete(); menu = null; nav.tick++ }) {
                            Text(S(R.string.s210), color = Color(0xFFE5484D))
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { menu = null }) { Text(S(R.string.s025)) } }
            )
        }
    }
}
