package com.mycx.explorer

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Update {
    const val REPO = "Neomelin/NM-"

    class Info(val version: String, val notes: String, val url: String)

    fun current(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "0"
    } catch (e: Exception) {
        "0"
    }

    fun newer(a: String, b: String): Boolean {
        val x = a.trim().removePrefix("v").split('.', '-').mapNotNull { it.toIntOrNull() }
        val y = b.trim().removePrefix("v").split('.', '-').mapNotNull { it.toIntOrNull() }
        for (i in 0 until maxOf(x.size, y.size)) {
            val p = x.getOrElse(i) { 0 }
            val q = y.getOrElse(i) { 0 }
            if (p != q) return p > q
        }
        return false
    }

    fun fetch(): Info? = try {
        val c = URL("https://api.github.com/repos/" + REPO + "/releases/latest").openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        if (c.responseCode != 200) {
            null
        } else {
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            Info(j.optString("tag_name"), j.optString("body"), j.optString("html_url"))
        }
    } catch (e: Exception) {
        null
    }
}

@Composable
fun UpdateCard() {
    val p = LocalP.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var state by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf<Update.Info?>(null) }
    val cur = remember { Update.current(ctx) }
    Column(Modifier.fillMaxWidth().neu(p, 18.dp).padding(16.dp)) {
        Text(S(R.string.s183), color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(4.dp))
        Text(S(R.string.s184) + cur, color = p.sub, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        when (state) {
            1 -> Text(S(R.string.s185), color = p.sub, fontSize = 13.sp)
            2 -> Text(S(R.string.s186), color = p.sub, fontSize = 13.sp)
            3 -> {
                Text(S(R.string.s187) + (info?.version ?: ""), color = p.accent, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Text(info?.notes ?: "", color = p.sub, fontSize = 12.sp, maxLines = 6, overflow = TextOverflow.Ellipsis)
                TextButton(onClick = {
                    val u = info?.url ?: ""
                    if (u.isNotEmpty()) ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text(S(R.string.s188), color = p.accent) }
            }
            4 -> Text(S(R.string.s189), color = Color(0xFFE5484D), fontSize = 13.sp)
        }
        TextButton(onClick = {
            state = 1
            scope.launch {
                val r = withContext(Dispatchers.IO) { Update.fetch() }
                if (r == null) {
                    state = 4
                } else if (Update.newer(r.version, cur)) {
                    info = r
                    state = 3
                } else {
                    state = 2
                }
            }
        }) { Text(S(R.string.s190), color = p.accent) }
    }
}

@Composable
fun CrashCard() {
    val p = LocalP.current
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val f = App.logFile()
    val has = remember(tick) { f.exists() && f.length() > 0 }
    Column(Modifier.fillMaxWidth().neu(p, 18.dp).padding(16.dp)) {
        Text(S(R.string.s191), color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(4.dp))
        Text(
            if (has) Fs.fmt(f.length()) else S(R.string.s192),
            color = p.sub, fontSize = 13.sp
        )
        Row {
            if (has) {
                TextButton(onClick = { Fs.share(ctx, f) }) { Text(S(R.string.s193), color = p.accent) }
                TextButton(onClick = { f.delete(); tick++ }) { Text(S(R.string.s138), color = Color(0xFFE5484D)) }
            }
        }
    }
}
