package com.mycx.explorer

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

class ArcEntry(val name: String, val size: Long, val dir: Boolean)

object Arc {
    fun kindOf(f: File): String? {
        val n = f.name.lowercase()
        return when {
            n.endsWith(".tar.gz") || n.endsWith(".tgz") -> "tgz"
            n.endsWith(".tar") -> "tar"
            n.endsWith(".gz") -> "gz"
            n.endsWith(".zip") || n.endsWith(".mcaddon") || n.endsWith(".mcpack") -> "zip"
            else -> null
        }
    }

    fun supported(f: File): Boolean = kindOf(f) != null

    private fun tarStream(f: File): InputStream {
        val raw = BufferedInputStream(f.inputStream())
        return if (kindOf(f) == "tgz") GZIPInputStream(raw) else raw
    }

    private fun readFully(s: InputStream, b: ByteArray): Boolean {
        var o = 0
        while (o < b.size) {
            val n = s.read(b, o, b.size - o)
            if (n < 0) return false
            o += n
        }
        return true
    }

    private fun skipN(s: InputStream, n: Long) {
        var left = n
        while (left > 0) {
            val k = s.skip(left)
            if (k > 0) {
                left -= k
            } else {
                if (s.read() < 0) return
                left--
            }
        }
    }

    private fun copyN(s: InputStream, o: OutputStream, n: Long) {
        var left = n
        val b = ByteArray(65536)
        while (left > 0) {
            val k = s.read(b, 0, minOf(left, b.size.toLong()).toInt())
            if (k < 0) return
            o.write(b, 0, k)
            left -= k
        }
    }

    private fun cstr(h: ByteArray, off: Int, len: Int): String {
        var n = 0
        while (n < len && h[off + n] != 0.toByte()) n++
        return String(h, off, n)
    }

    private fun fullName(h: ByteArray): String {
        val name = cstr(h, 0, 100)
        val prefix = cstr(h, 345, 155)
        return if (prefix.isNotEmpty()) prefix + "/" + name else name
    }

    fun list(f: File): List<ArcEntry>? = try {
        when (kindOf(f)) {
            "zip" -> ZipFile(f).use { z ->
                z.entries().asSequence().map { ArcEntry(it.name, it.size, it.isDirectory) }.toList()
            }
            "tar", "tgz" -> {
                val res = ArrayList<ArcEntry>()
                tarStream(f).use { s ->
                    val h = ByteArray(512)
                    while (readFully(s, h)) {
                        if (h.all { it == 0.toByte() }) break
                        val name = fullName(h)
                        val size = cstr(h, 124, 12).trim().toLongOrNull(8) ?: 0L
                        val type = h[156].toInt().toChar()
                        res.add(ArcEntry(name, size, type == '5'))
                        skipN(s, ((size + 511L) / 512L) * 512L)
                    }
                }
                res
            }
            "gz" -> listOf(ArcEntry(f.nameWithoutExtension, f.length(), false))
            else -> null
        }
    } catch (e: Exception) {
        null
    }

    fun extractAll(f: File, dst: File) {
        dst.mkdirs()
        val base = dst.canonicalPath + File.separator
        when (kindOf(f)) {
            "zip" -> ZipInputStream(f.inputStream().buffered()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val out = File(dst, e.name)
                    if (out.canonicalPath.startsWith(base)) {
                        if (e.isDirectory) {
                            out.mkdirs()
                        } else {
                            out.parentFile?.mkdirs()
                            out.outputStream().use { o -> zin.copyTo(o) }
                        }
                    }
                    zin.closeEntry()
                    e = zin.nextEntry
                }
            }
            "tar", "tgz" -> tarStream(f).use { s ->
                val h = ByteArray(512)
                while (readFully(s, h)) {
                    if (h.all { it == 0.toByte() }) break
                    val name = fullName(h)
                    val size = cstr(h, 124, 12).trim().toLongOrNull(8) ?: 0L
                    val type = h[156].toInt().toChar()
                    val out = File(dst, name)
                    val safe = out.canonicalPath.startsWith(base)
                    if (safe && type == '5') {
                        out.mkdirs()
                    } else if (safe && (type == '0' || type == '\u0000')) {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { o -> copyN(s, o, size) }
                    } else {
                        skipN(s, size)
                    }
                    val pad = (512L - size % 512L) % 512L
                    skipN(s, pad)
                }
            }
            "gz" -> GZIPInputStream(f.inputStream().buffered()).use { g ->
                File(dst, f.nameWithoutExtension).outputStream().use { o -> g.copyTo(o) }
            }
            else -> { }
        }
    }
}

@Composable
fun ArcDialog(nav: Nav, f: File) {
    val entries by produceState<List<ArcEntry>?>(null, f.path) {
        value = withContext(Dispatchers.IO) { Arc.list(f) ?: emptyList() }
    }
    AlertDialog(
        onDismissRequest = { nav.arcFile = null },
        title = { Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            val l = entries
            if (l == null) {
                Text(S(R.string.s022))
            } else {
                Column {
                    Text(
                        S(R.string.s012) + l.count { !it.dir } + S(R.string.s023) + Fs.fmt(l.sumOf { it.size }),
                        fontSize = 12.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.heightIn(max = 280.dp)) {
                        items(l.take(500)) { e ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                Text(e.name, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                Text(if (e.dir) "" else Fs.fmt(e.size), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { nav.unzip(f); nav.arcFile = null }) { Text(S(R.string.s024)) } },
        dismissButton = { TextButton(onClick = { nav.arcFile = null }) { Text(S(R.string.s025)) } }
    )
}
