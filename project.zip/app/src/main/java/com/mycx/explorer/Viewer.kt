package com.mycx.explorer

import android.graphics.Bitmap
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun Viewer(req: ViewerReq, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { }) {
        val f = req.files[req.index]
        if (Fs.kind(f) == Kind.VID) {
            VideoPlayer(f)
        } else {
            val state = rememberPagerState(initialPage = req.index) { req.files.size }
            HorizontalPager(state, Modifier.fillMaxSize()) { page -> ZoomImage(req.files[page]) }
        }
        Box(
            Modifier.align(Alignment.TopStart).padding(14.dp).size(44.dp).clip(CircleShape)
                .background(Color.White.copy(alpha = 0.22f)).clickable(onClick = onClose),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Close, null, tint = Color.White) }
    }
}

@Composable
fun ZoomImage(f: File) {
    val bmp by produceState<Bitmap?>(null, f.path) { value = withContext(Dispatchers.IO) { Thumbs.full(f) } }
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    Box(
        Modifier.fillMaxSize().pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                do {
                    val ev = awaitPointerEvent()
                    if (ev.changes.size > 1 || scale > 1f) {
                        val zoom = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        scale = (scale * zoom).coerceIn(1f, 5f)
                        off = if (scale > 1f) off + pan else Offset.Zero
                        ev.changes.forEach { if (it.positionChanged()) it.consume() }
                    }
                } while (ev.changes.any { it.pressed })
            }
        },
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                b.asImageBitmap(), null,
                Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y },
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
fun VideoPlayer(f: File) {
    AndroidView(
        factory = { ctx ->
            VideoView(ctx).apply {
                val mc = MediaController(ctx)
                mc.setAnchorView(this)
                setMediaController(mc)
                setVideoPath(f.path)
                setOnPreparedListener { start() }
            }
        },
        modifier = Modifier.fillMaxSize(),
        onRelease = { it.stopPlayback() }
    )
}

@Composable
fun TextViewer(f: File, onClose: () -> Unit) {
    val p = LocalP.current
    var editing by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    var ver by remember { mutableIntStateOf(0) }
    BackHandler { if (editing) editing = false else onClose() }
    val text by produceState<String?>(null, f.path, ver) {
        value = withContext(Dispatchers.IO) {
            try { f.readText().take(300_000) } catch (e: Exception) { "Не удалось прочитать файл" }
        }
    }
    val canEdit = f.length() <= 300_000 && f.canWrite()
    Column(Modifier.fillMaxSize().background(p.bg).pointerInput(Unit) { }) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            NeuBtn(Icons.Default.Close) { if (editing) editing = false else onClose() }
            Spacer(Modifier.width(12.dp))
            Text(f.name, color = p.text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (canEdit && text != null) {
                NeuBtn(if (editing) Icons.Default.Check else Icons.Default.Edit) {
                    if (editing) {
                        try { f.writeText(draft) } catch (_: Exception) { }
                        editing = false
                        ver++
                    } else {
                        draft = text ?: ""
                        editing = true
                    }
                }
            }
        }
        if (editing) {
            OutlinedTextField(
                value = draft, onValueChange = { draft = it },
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = p.text)
            )
        } else {
            SelectionContainer {
                Text(
                    text ?: "Загрузка…", color = p.text, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    }
}
