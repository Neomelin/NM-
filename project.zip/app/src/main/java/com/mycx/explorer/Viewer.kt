package com.mycx.explorer

import android.graphics.Bitmap
import android.media.MediaPlayer
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun Viewer(req: ViewerReq, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { }) {
        val f = req.files[req.index]
        if (Fs.kind(f) == Kind.VID) {
            VideoPlayer(f)
        } else {
            val state = rememberPagerState(initialPage = req.index) { req.files.size }
            HorizontalPager(state, Modifier.fillMaxSize()) { page -> ZoomImage(req.files[page]) }
            Text(
                "${state.currentPage + 1} / ${req.files.size}", color = Color.White, fontSize = 14.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 24.dp)
                    .clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.2f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
        Box(
            Modifier.align(Alignment.TopStart).padding(14.dp).size(44.dp).clip(CircleShape)
                .background(Color.White.copy(alpha = 0.22f)).clickable(onClick = onClose),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Close, null, tint = Color.White) }
    }
}

@Composable
fun ZoomImage(f: File) {
    val bmp by produceState<Bitmap?>(null, f.path) { value = withContext(Dispatchers.IO) { Thumbs.full(f) } }
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    Box(
        Modifier.fillMaxSize().pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                do {
                    val ev = awaitPointerEvent()
                    if (ev.changes.size > 1 || scale > 1f) {
                        val zoom = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        scale = (scale * zoom).coerceIn(1f, 5f)
                        off = if (scale > 1f) off + pan else Offset.Zero
                        ev.changes.forEach { if (it.positionChanged()) it.consume() }
                    }
                } while (ev.changes.any { it.pressed })
            }
        },
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                b.asImageBitmap(), null,
                Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y },
                contentScale = ContentScale.Fit
            )
        }
    }
}

class VH(val vv: VideoView, val mc: MediaController) {
    var mp: MediaPlayer? = null
}

@Composable
fun VideoPlayer(f: File) {
    var holder by remember { mutableStateOf<VH?>(null) }
    var speed by remember { mutableFloatStateOf(1f) }
    var hint by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(hint) {
        if (hint != null) {
            delay(700)
            hint = null
        }
    }
    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { ctx ->
                val vv = VideoView(ctx)
                val mc = MediaController(ctx)
                mc.setAnchorView(vv)
                vv.setMediaController(mc)
                vv.setVideoPath(f.path)
                val h = VH(vv, mc)
                vv.setOnPreparedListener { m -> h.mp = m; vv.start() }
                holder = h
                vv
            },
            modifier = Modifier.fillMaxSize(),
            onRelease = { it.stopPlayback() }
        )
        Row(Modifier.fillMaxSize()) {
            listOf(-10000, 10000).forEach { delta ->
                Box(
                    Modifier.weight(1f).fillMaxHeight().pointerInput(delta) {
                        detectTapGestures(
                            onTap = { holder?.let { h -> if (h.mc.isShowing) h.mc.hide() else h.mc.show(3000) } },
                            onDoubleTap = {
                                holder?.let { h ->
                                    val t = (h.vv.currentPosition + delta).coerceIn(0, maxOf(h.vv.duration, 0))
                                    h.vv.seekTo(t)
                                    hint = if (delta > 0) "+10 с" else "-10 с"
                                }
                            }
                        )
                    }
                )
            }
        }
        Box(
            Modifier.align(Alignment.TopEnd).padding(14.dp).clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = 0.22f))
                .clickable {
                    val next = when (speed) { 1f -> 1.5f; 1.5f -> 2f; 2f -> 0.5f; else -> 1f }
                    speed = next
                    holder?.mp?.let { m ->
                        try { m.playbackParams = m.playbackParams.setSpeed(next) } catch (_: Exception) { }
                    }
                }
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) { Text("${speed}x", color = Color.White, fontSize = 14.sp) }
        val hi = hint
        if (hi != null) {
            Text(
                hi, color = Color.White, fontSize = 22.sp,
                modifier = Modifier.align(Alignment.Center).clip(RoundedCornerShape(16.dp))
                    .background(Color.Black.copy(alpha = 0.5f)).padding(horizontal = 18.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
fun TextViewer(f: File, startEditing: Boolean, onClose: () -> Unit) {
    val p = LocalP.current
    val scope = rememberCoroutineScope()
    val hash = f.extension.lowercase() in setOf("py", "plugin", "sh", "yml", "yaml", "conf", "ini", "properties", "txt", "md")
    var editing by remember { mutableStateOf(false) }
    var tv by remember { mutableStateOf(TextFieldValue("")) }
    var ver by remember { mutableIntStateOf(0) }
    val undo = remember { ArrayList<String>() }
    val redo = remember { ArrayList<String>() }
    var lastPush by remember { mutableLongStateOf(0L) }
    var find by remember { mutableStateOf("") }
    var repl by remember { mutableStateOf("") }
    var showFind by remember { mutableStateOf(false) }
    var dirty by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }
    var started by remember { mutableStateOf(false) }
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()
    val lh = with(LocalDensity.current) { 18.sp.toPx() }
    val text by produceState<String?>(null, f.path, ver) {
        value = withContext(Dispatchers.IO) {
            try { f.readText().take(300_000) } catch (e: Exception) { "Не удалось прочитать файл" }
        }
    }
    val canEdit = f.length() <= 300_000 && f.canWrite()
    LaunchedEffect(text) {
        if (startEditing && !started && text != null && canEdit) {
            tv = TextFieldValue(text ?: "")
            editing = true
            started = true
        }
    }
    LaunchedEffect(toast) {
        if (toast != null) {
            delay(1800)
            toast = null
        }
    }
    val closeOrExit: () -> Unit = {
        if (editing) {
            if (dirty) toast = "Изменения отброшены"
            editing = false
            dirty = false
            showFind = false
        } else {
            onClose()
        }
    }
    BackHandler { closeOrExit() }

    val push: (String) -> Unit = { old ->
        val now = System.currentTimeMillis()
        if (now - lastPush > 700 || undo.isEmpty()) {
            undo.add(old)
            if (undo.size > 60) undo.removeAt(0)
        }
        lastPush = now
        redo.clear()
    }
    val doUndo: () -> Unit = {
        if (undo.isNotEmpty()) {
            redo.add(tv.text)
            val t = undo.removeAt(undo.lastIndex)
            tv = TextFieldValue(t, TextRange(minOf(t.length, tv.selection.end)))
            dirty = true
        }
    }
    val doRedo: () -> Unit = {
        if (redo.isNotEmpty()) {
            undo.add(tv.text)
            val t = redo.removeAt(redo.lastIndex)
            tv = TextFieldValue(t, TextRange(minOf(t.length, tv.selection.end)))
            dirty = true
        }
    }
    val doFind: () -> Unit = {
        if (find.isNotEmpty()) {
            val from = minOf(tv.selection.end, tv.text.length)
            var i = tv.text.indexOf(find, from, ignoreCase = true)
            if (i < 0) i = tv.text.indexOf(find, 0, ignoreCase = true)
            if (i >= 0) {
                tv = tv.copy(selection = TextRange(i, i + find.length))
                val line = tv.text.substring(0, i).count { it == '\n' }
                scope.launch { vScroll.animateScrollTo((line * lh).toInt()) }
            } else {
                toast = "Не найдено"
            }
        }
    }
    val doReplace: () -> Unit = {
        val s = tv.selection
        if (find.isNotEmpty() && s.length == find.length && tv.text.substring(s.min, s.max).equals(find, ignoreCase = true)) {
            push(tv.text)
            dirty = true
            val nt = tv.text.replaceRange(s.min, s.max, repl)
            tv = TextFieldValue(nt, TextRange(s.min + repl.length))
        }
        doFind()
    }
    val doAll: () -> Unit = {
        if (find.isNotEmpty()) {
            push(tv.text)
            dirty = true
            tv = TextFieldValue(tv.text.replace(find, repl, ignoreCase = true))
            toast = "Заменено"
        }
    }
    val doSave: () -> Unit = {
        try {
            f.writeText(tv.text)
            toast = "Сохранено"
            dirty = false
            ver++
        } catch (e: Exception) {
            toast = "Ошибка сохранения"
        }
    }

    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 18.sp, color = p.text)
    val content = if (editing) tv.text else (text ?: "")
    val lineCount = remember(content) { content.count { it == '\n' } + 1 }
    val nums = remember(lineCount) { (1..lineCount).joinToString("\n") }
    val hl = remember(text, hash, p.dark) { Syntax.highlight(text ?: "", hash, p.dark) }
    val trans = remember(hash, p.dark) { SyntaxTransformation(hash, p.dark) }

    Column(Modifier.fillMaxSize().background(p.bg).pointerInput(Unit) { }) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            NeuBtn(Icons.Default.Close) { closeOrExit() }
            Spacer(Modifier.width(12.dp))
            Text(
                toast ?: f.name, color = if (toast != null) p.accent else p.text, fontSize = 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            if (editing) {
                NeuBtn(Icons.Default.Undo) { doUndo() }
                Spacer(Modifier.width(8.dp))
                NeuBtn(Icons.Default.Redo) { doRedo() }
                Spacer(Modifier.width(8.dp))
                NeuBtn(Icons.Default.Search) { showFind = !showFind }
                Spacer(Modifier.width(8.dp))
                NeuBtn(Icons.Default.Check) { doSave() }
            } else if (canEdit && text != null) {
                NeuBtn(Icons.Default.Edit) {
                    tv = TextFieldValue(text ?: "")
                    undo.clear()
                    redo.clear()
                    dirty = false
                    editing = true
                }
            }
        }
        if (editing && showFind) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(find, { find = it }, singleLine = true, label = { Text("Найти") }, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    OutlinedTextField(repl, { repl = it }, singleLine = true, label = { Text("Заменить") }, modifier = Modifier.weight(1f))
                }
                Row {
                    TextButton(onClick = { doFind() }) { Text("Далее") }
                    TextButton(onClick = { doReplace() }) { Text("Заменить") }
                    TextButton(onClick = { doAll() }) { Text("Все") }
                }
            }
        }
        Row(Modifier.weight(1f).fillMaxWidth().verticalScroll(vScroll)) {
            Text(
                nums, style = mono.copy(color = p.sub), textAlign = TextAlign.End,
                modifier = Modifier.width(((lineCount.toString().length * 8) + 20).dp).padding(end = 8.dp)
            )
            Box(Modifier.weight(1f).horizontalScroll(hScroll)) {
                if (editing) {
                    BasicTextField(
                        value = tv,
                        onValueChange = { nv ->
                            if (nv.text != tv.text) {
                                push(tv.text)
                                dirty = true
                            }
                            tv = nv
                        },
                        textStyle = mono,
                        cursorBrush = SolidColor(p.accent),
                        visualTransformation = trans,
                        modifier = Modifier.widthIn(min = 300.dp).padding(end = 24.dp)
                    )
                } else {
                    SelectionContainer { Text(hl, style = mono, modifier = Modifier.padding(end = 24.dp)) }
                }
            }
        }
    }
}
