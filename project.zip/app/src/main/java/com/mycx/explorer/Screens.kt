package com.mycx.explorer

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.StatFs
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val df = SimpleDateFormat("dd.MM.yy HH:mm", Locale.getDefault())

class Tile(val e: String, val t: String, val go: () -> Unit)

@Composable
fun NeuBtn(icon: ImageVector, onClick: () -> Unit) {
    val p = LocalP.current
    Box(Modifier.size(42.dp).neu(p, 21.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = p.sub)
    }
}

@Composable
fun Home(nav: Nav, onSaf: () -> Unit) {
    val p = LocalP.current
    val st = LocalSettings.current
    val ctx = LocalContext.current
    val sf = remember { StatFs(Fs.root.path) }
    val total = sf.totalBytes
    val free = sf.availableBytes
    val used = total - free
    val recent = remember(nav.tick) { Fs.recent() }
    val tiles = listOf(
        Tile("📷", "Фото") { nav.goDir(File(Fs.root, "DCIM")) },
        Tile("🎬", "Видео") { nav.goDir(File(Fs.root, "Movies")) },
        Tile("⬇️", "Загрузки") { nav.goDir(File(Fs.root, "Download")) },
        Tile("🖼", "Картинки") { nav.goDir(File(Fs.root, "Pictures")) },
        Tile("🎵", "Музыка") { nav.goDir(File(Fs.root, "Music")) },
        Tile("📄", "Документы") { nav.goDir(File(Fs.root, "Documents")) },
        Tile("🗄", "Android/data") {
            val u = st.safUri
            if (Build.VERSION.SDK_INT >= 33) nav.tab = 3
            else if (u != null) nav.goSaf(ctx, u)
            else onSaf()
        },
        Tile("📱", "Программы") { nav.tab = 4 },
        Tile("🗑", "Корзина") { nav.tab = 2 }
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 110.dp)
    ) {
        Text("NMПроводник", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(16.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))) {
            Canvas(Modifier.matchParentSize()) {
                drawRect(Color(0xFF6A4BFF))
                val r1 = size.width * 0.6f
                drawCircle(
                    brush = Brush.radialGradient(listOf(Color(0xFFFF7AB8), Color.Transparent), center = Offset(size.width * 0.9f, 0f), radius = r1),
                    radius = r1, center = Offset(size.width * 0.9f, 0f)
                )
                val r2 = size.width * 0.5f
                drawCircle(
                    brush = Brush.radialGradient(listOf(Color(0xFF4FC3FF), Color.Transparent), center = Offset(0f, size.height), radius = r2),
                    radius = r2, center = Offset(0f, size.height)
                )
            }
            Column(
                Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.14f))
                    .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(28.dp)).padding(18.dp)
            ) {
                Text("Память телефона", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                Text(Fs.fmt(used), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Medium)
                Text("из ${Fs.fmt(total)} · свободно ${Fs.fmt(free)}", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.3f))) {
                    Box(Modifier.fillMaxWidth((used.toFloat() / total).coerceIn(0.02f, 1f)).fillMaxHeight().clip(CircleShape).background(Color.White))
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        tiles.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                row.forEach { t ->
                    Column(
                        Modifier.weight(1f).aspectRatio(1f).neu(p, 20.dp).clip(RoundedCornerShape(20.dp)).clickable { t.go() },
                        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(t.e, fontSize = 28.sp)
                        Text(t.t, color = p.sub, fontSize = 12.sp)
                    }
                }
            }
        }
        if (recent.isNotEmpty()) {
            Spacer(Modifier.height(24.dp))
            Text("Недавние", color = p.sub, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                val shown = recent.take(4)
                shown.forEach { f ->
                    Box(Modifier.weight(1f).aspectRatio(1f).neu(p, 16.dp).padding(6.dp)) {
                        Thumb(f, Modifier.fillMaxSize().clickable { nav.open(ctx, f, recent) }, px = 200, radius = 12.dp)
                    }
                }
                repeat(4 - shown.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun Crumb(text: String, last: Boolean, onClick: () -> Unit) {
    val p = LocalP.current
    Text(
        text, color = if (last) p.accent else p.sub, fontSize = 14.sp, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 10.dp)
    )
}

@Composable
fun Files(nav: Nav) {
    val p = LocalP.current
    val st = LocalSettings.current
    var menu by remember { mutableStateOf(false) }
    val inSaf = nav.saf.isNotEmpty()
    val list = remember(nav.dir, nav.tick, st.hidden, st.sort, inSaf) {
        if (inSaf) emptyList() else Fs.list(nav.dir, st.hidden, st.sort)
    }
    val docs = remember(nav.saf, nav.tick) { if (inSaf) Fs.listDoc(nav.saf.last()) else emptyList() }
    val found by produceState<List<File>>(emptyList(), nav.query, nav.dir, nav.searching) {
        val q = nav.query.trim()
        value = if (!nav.searching || q.length < 2 || nav.saf.isNotEmpty()) {
            emptyList()
        } else {
            withContext(Dispatchers.IO) {
                nav.dir.walkTopDown().maxDepth(8).onEnter { !it.name.startsWith(".") }
                    .filter { it != nav.dir && it.name.contains(q, ignoreCase = true) }
                    .take(200).toList()
            }
        }
    }
    val shown = if (nav.searching) found else list

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (nav.searching) {
                OutlinedTextField(
                    value = nav.query, onValueChange = { nav.query = it }, singleLine = true,
                    placeholder = { Text("Поиск в этой папке") }, modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(10.dp))
                NeuBtn(Icons.Default.Close) { nav.searching = false; nav.query = "" }
            } else {
                Row(
                    Modifier.weight(1f).glass(p, 22.dp).horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (inSaf) {
                        nav.saf.forEachIndexed { i, d ->
                            Crumb(if (i == 0) "Android/data" else (d.name ?: "?"), i == nav.saf.lastIndex) { nav.saf = nav.saf.take(i + 1) }
                            if (i < nav.saf.lastIndex) Text("›", color = p.sub)
                        }
                    } else {
                        val parts = generateSequence(nav.dir) { if (it == Fs.root) null else it.parentFile }.toList().reversed()
                        parts.forEachIndexed { i, f ->
                            Crumb(if (f == Fs.root) "Память" else f.name, i == parts.lastIndex) { nav.dir = f; nav.sel = emptySet() }
                            if (i < parts.lastIndex) Text("›", color = p.sub)
                        }
                    }
                }
                if (!inSaf) {
                    Spacer(Modifier.width(10.dp))
                    NeuBtn(Icons.Default.Search) { nav.searching = true }
                    Spacer(Modifier.width(10.dp))
                    Box {
                        NeuBtn(Icons.Default.Add) { menu = true }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text("Новая папка") }, onClick = { menu = false; nav.dialogText = ""; nav.dialog = "mkdir" })
                        }
                    }
                }
            }
        }
        val clip = nav.clip
        if (clip != null && !inSaf) {
            Box(
                Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth().neu(p, 16.dp)
                    .clip(RoundedCornerShape(16.dp)).clickable { nav.paste() }.padding(12.dp),
                contentAlignment = Alignment.Center
            ) { Text("Вставить сюда (${clip.first.size})", color = p.accent) }
        }
        val empty = if (inSaf) docs.isEmpty() else shown.isEmpty()
        if (empty) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text(
                    if (nav.searching) (if (nav.query.trim().length < 2) "Введите минимум 2 символа" else "Ничего не найдено") else "Пусто или нет доступа",
                    color = p.sub
                )
            }
        } else if (inSaf) {
            LazyColumn(
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 110.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) { items(docs, key = { it.uri.toString() }) { d -> DocRow(d, nav) } }
        } else if (st.grid && !nav.searching) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 110.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) { items(shown, key = { it.path }) { f -> GridCell(f, shown, nav) } }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 110.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) { items(shown, key = { it.path }) { f -> FileRow(f, shown, nav) } }
        }
    }

    val dlg = nav.dialog
    if (dlg != null) {
        AlertDialog(
            onDismissRequest = { nav.dialog = null },
            title = { Text(when (dlg) { "mkdir" -> "Новая папка"; "unzip" -> "Распаковать архив?"; else -> "Новое имя" }) },
            text = {
                if (dlg == "unzip") Text(nav.pendingZip?.name ?: "")
                else OutlinedTextField(value = nav.dialogText, onValueChange = { nav.dialogText = it }, singleLine = true)
            },
            confirmButton = { TextButton(onClick = { nav.confirmDialog() }) { Text(if (dlg == "unzip") "Распаковать" else "ОК") } },
            dismissButton = { TextButton(onClick = { nav.dialog = null }) { Text("Отмена") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(f: File, siblings: List<File>, nav: Nav) {
    val p = LocalP.current
    val ctx = LocalContext.current
    val picked = f in nav.sel
    Row(
        Modifier.fillMaxWidth()
            .then(if (picked) Modifier.inset(p, 18.dp) else Modifier.neu(p, 18.dp))
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = {
                    if (nav.sel.isNotEmpty()) nav.toggle(f)
                    else if (f.isDirectory) { nav.dir = f; nav.searching = false; nav.query = "" }
                    else nav.open(ctx, f, siblings)
                },
                onLongClick = { nav.toggle(f) }
            )
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(f, Modifier.size(50.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (f.isDirectory) "${f.listFiles()?.size ?: 0} объектов" else "${Fs.fmt(f.length())} · ${df.format(Date(f.lastModified()))}",
                color = p.sub, fontSize = 12.sp
            )
        }
        if (picked) Icon(Icons.Default.Check, null, tint = p.accent)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GridCell(f: File, siblings: List<File>, nav: Nav) {
    val p = LocalP.current
    val ctx = LocalContext.current
    val picked = f in nav.sel
    Column(
        Modifier.fillMaxWidth()
            .then(if (picked) Modifier.inset(p, 16.dp) else Modifier.neu(p, 16.dp))
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(
                onClick = {
                    if (nav.sel.isNotEmpty()) nav.toggle(f)
                    else if (f.isDirectory) { nav.dir = f; nav.searching = false; nav.query = "" }
                    else nav.open(ctx, f, siblings)
                },
                onLongClick = { nav.toggle(f) }
            )
            .padding(6.dp)
    ) {
        Thumb(f, Modifier.fillMaxWidth().aspectRatio(1f), px = 256, radius = 12.dp)
        Text(f.name, color = p.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp, start = 2.dp))
    }
}

@Composable
fun DocRow(d: DocumentFile, nav: Nav) {
    val p = LocalP.current
    val ctx = LocalContext.current
    val name = d.name ?: "?"
    val k = Fs.kindOf(name, d.isDirectory)
    Row(
        Modifier.fillMaxWidth().neu(p, 18.dp).clip(RoundedCornerShape(18.dp))
            .clickable { if (d.isDirectory) nav.saf = nav.saf + d else Fs.openDoc(ctx, d) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)).background(tint(k)), contentAlignment = Alignment.Center) {
            Text(Fs.glyph(k), fontSize = 24.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (d.isDirectory) "папка" else Fs.fmt(d.length()), color = p.sub, fontSize = 12.sp)
        }
    }
}

@Composable
fun TrashScreen(nav: Nav) {
    val p = LocalP.current
    val list = remember(nav.tick) { Fs.trashed() }
    var ask by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(start = 20.dp, end = 20.dp, top = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Корзина", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            if (list.isNotEmpty()) TextButton(onClick = { ask = true }) { Text("Очистить", color = p.accent) }
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Корзина пуста", color = p.sub) }
        } else {
            LazyColumn(contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(list, key = { it.first.path }) { (f, orig) ->
                    Row(Modifier.fillMaxWidth().neu(p, 18.dp).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Thumb(f, Modifier.size(50.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name.substringAfter('_'), color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(Fs.fmt(Fs.size(f)), color = p.sub, fontSize = 12.sp)
                        }
                        TextButton(onClick = { Fs.restore(f, orig); nav.tick++ }) { Text("Вернуть", color = p.accent) }
                    }
                }
            }
        }
    }
    if (ask) {
        AlertDialog(
            onDismissRequest = { ask = false },
            title = { Text("Очистить корзину?") },
            text = { Text("Файлы будут удалены навсегда.") },
            confirmButton = { TextButton(onClick = { Fs.emptyTrash(); ask = false; nav.tick++ }) { Text("Удалить", color = Color(0xFFE5484D)) } },
            dismissButton = { TextButton(onClick = { ask = false }) { Text("Отмена") } }
        )
    }
}

@Composable
fun SwitchRow(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalP.current
    Row(Modifier.fillMaxWidth().neu(p, 18.dp).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = p.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = p.accent, checkedThumbColor = Color.White))
    }
}

@Composable
fun SettingsScreen(onSaf: () -> Unit) {
    val p = LocalP.current
    val st = LocalSettings.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Настройки", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        SwitchRow("Тёмная тема", st.dark) { st.putDark(it) }
        SwitchRow("Показывать скрытые файлы", st.hidden) { st.putHidden(it) }
        SwitchRow("Плитки вместо списка", st.grid) { st.putGrid(it) }
        Text("Сортировка", color = p.sub, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf("Имя", "Дата", "Размер").forEachIndexed { i, label ->
                Box(
                    Modifier.weight(1f).height(44.dp)
                        .then(if (st.sort == i) Modifier.inset(p, 16.dp) else Modifier.neu(p, 16.dp))
                        .clip(RoundedCornerShape(16.dp)).clickable { st.putSort(i) },
                    contentAlignment = Alignment.Center
                ) { Text(label, color = if (st.sort == i) p.accent else p.text, fontSize = 14.sp) }
            }
        }
        Column(Modifier.fillMaxWidth().neu(p, 18.dp).padding(16.dp)) {
            Text("Доступ к Android/data", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            if (Build.VERSION.SDK_INT >= 33) {
                Text(
                    "На Android 13 и новее система закрывает Android/data и Android/obb для всех файловых менеджеров. Обойти это можно только через Shizuku или ADB.",
                    color = p.sub, fontSize = 13.sp
                )
            } else {
                Text(
                    "В системном окне откройте Android/data и нажмите «Использовать эту папку».",
                    color = p.sub, fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextButton(onClick = onSaf) { Text(if (st.safUri == null) "Выбрать папку" else "Выбрать заново", color = p.accent) }
                    if (st.safUri != null) TextButton(onClick = { st.putSafUri(null) }) { Text("Сбросить", color = Color(0xFFE5484D)) }
                }
            }
        }
        Text("NMПроводник 0.3", color = p.sub, fontSize = 12.sp)
    }
}

@Composable
fun NavBar(nav: Nav, modifier: Modifier) {
    val p = LocalP.current
    val icons = listOf(Icons.Default.Home, Icons.Default.List, Icons.Default.Delete, Icons.Default.Settings)
    Row(
        modifier.fillMaxWidth(0.86f).glass(p, 32.dp).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically
    ) {
        icons.forEachIndexed { i, ic ->
            Box(
                Modifier.size(width = 62.dp, height = 42.dp).clip(RoundedCornerShape(21.dp))
                    .background(if (nav.tab == i) p.accent.copy(alpha = 0.22f) else Color.Transparent)
                    .clickable { nav.tab = i; if (i == 2) nav.tick++ },
                contentAlignment = Alignment.Center
            ) { Icon(ic, null, tint = if (nav.tab == i) p.accent else p.sub) }
        }
    }
}

@Composable
fun SelBar(nav: Nav, modifier: Modifier) {
    val p = LocalP.current
    Row(
        modifier.fillMaxWidth(0.92f).glass(p, 30.dp).padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        Text("${nav.sel.size}", color = p.accent, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 8.dp))
        TextButton(onClick = { nav.clip = nav.sel.toList() to false; nav.sel = emptySet() }) { Text("Копия", color = p.text) }
        TextButton(onClick = { nav.clip = nav.sel.toList() to true; nav.sel = emptySet() }) { Text("Перенос", color = p.text) }
        if (nav.sel.size == 1) {
            TextButton(onClick = { nav.dialogText = nav.sel.first().name; nav.dialog = "rename" }) { Text("Имя", color = p.text) }
        }
        TextButton(onClick = { nav.trashSel() }) { Text("Корзина", color = Color(0xFFE5484D)) }
    }
}

class AppInfo(val label: String, val pkg: String, val apk: String, val size: Long, val icon: Bitmap?)

@Composable
fun AppsScreen(nav: Nav) {
    val p = LocalP.current
    val ctx = LocalContext.current
    val apps by produceState<List<AppInfo>?>(null) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            pm.getInstalledApplications(0)
                .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                .map { ai ->
                    AppInfo(
                        pm.getApplicationLabel(ai).toString(), ai.packageName, ai.sourceDir, File(ai.sourceDir).length(),
                        try { pm.getApplicationIcon(ai).toBitmap(96, 96) } catch (e: Exception) { null }
                    )
                }
                .sortedBy { it.label.lowercase() }
        }
    }
    var picked by remember { mutableStateOf<AppInfo?>(null) }
    Column(Modifier.fillMaxSize().padding(start = 20.dp, end = 20.dp, top = 16.dp)) {
        Text("Программы", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        val list = apps
        if (list == null) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Загрузка…", color = p.sub) }
        } else {
            LazyColumn(contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(list, key = { it.pkg }) { a ->
                    Row(
                        Modifier.fillMaxWidth().neu(p, 18.dp).clip(RoundedCornerShape(18.dp)).clickable { picked = a }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                            val ic = a.icon
                            if (ic != null) Image(ic.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                            else Text("📱", fontSize = 24.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.label, color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${Fs.fmt(a.size)} · ${a.pkg}", color = p.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
    val a = picked
    if (a != null) {
        AlertDialog(
            onDismissRequest = { picked = null },
            title = { Text(a.label) },
            text = {
                Column {
                    Text("${a.pkg}\n${Fs.fmt(a.size)}", fontSize = 13.sp)
                    Row {
                        TextButton(onClick = { ctx.packageManager.getLaunchIntentForPackage(a.pkg)?.let { ctx.startActivity(it) }; picked = null }) { Text("Открыть") }
                        TextButton(onClick = {
                            ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            picked = null
                        }) { Text("Сведения") }
                    }
                    Row {
                        TextButton(onClick = {
                            nav.status = "Сохраняю APK…"
                            Thread {
                                try {
                                    val dir = File(Fs.root, "Download/APK")
                                    dir.mkdirs()
                                    File(a.apk).copyTo(Fs.unique(dir, a.label + ".apk"))
                                    nav.status = "APK в Download/APK"
                                } catch (_: Exception) {
                                    nav.status = "Не удалось сохранить"
                                }
                                Thread.sleep(2500)
                                nav.status = null
                            }.start()
                            picked = null
                        }) { Text("Извлечь APK") }
                        TextButton(onClick = {
                            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            picked = null
                        }) { Text("Удалить", color = Color(0xFFE5484D)) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { picked = null }) { Text("Закрыть") } }
        )
    }
}

@Composable
fun AudioBar(nav: Nav, modifier: Modifier) {
    val p = LocalP.current
    val a = nav.audio
    Row(
        modifier.fillMaxWidth(0.92f).glass(p, 26.dp).padding(horizontal = 14.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("🎵", fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Text(a.current?.name ?: "", color = p.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        TextButton(onClick = { a.toggle() }) { Text(if (a.playing) "⏸" else "▶", fontSize = 20.sp, color = p.accent) }
        TextButton(onClick = { a.stop() }) { Text("✕", fontSize = 18.sp, color = p.sub) }
    }
}
