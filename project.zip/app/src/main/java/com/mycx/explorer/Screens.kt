package com.mycx.explorer

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.StatFs
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val df = SimpleDateFormat("dd.MM.yy HH:mm", Locale.getDefault())

class Tile(val icon: ImageVector, val color: Color, val t: String, val go: () -> Unit)

@Composable
fun NeuBtn(icon: ImageVector, desc: String?, onClick: () -> Unit) {
    val p = LocalP.current
    Box(Modifier.size(42.dp).neu(p, 21.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, desc, tint = p.sub)
    }
}

@Composable
fun NeuBtn(icon: ImageVector, onClick: () -> Unit) {
    NeuBtn(icon, null, onClick)
}

@Composable
fun HomeCard(icon: ImageVector, color: Color, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalP.current
    Column(modifier.neu(p, 22.dp).clip(RoundedCornerShape(22.dp)).clickable(onClick = onClick).padding(16.dp)) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(color.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = color, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Text(sub, color = p.sub, fontSize = 12.sp)
    }
}

@Composable
fun SectionTitle(text: String) {
    val p = LocalP.current
    Row(Modifier.padding(top = 24.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 4.dp, height = 16.dp).clip(CircleShape).background(p.accent))
        Spacer(Modifier.width(8.dp))
        Text(text, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Home(nav: Nav, onSaf: () -> Unit) {
    val p = LocalP.current
    val st = LocalSettings.current
    val ctx = LocalContext.current
    val sf = remember { StatFs(Fs.root.path) }
    val total = sf.totalBytes
    val free = sf.availableBytes
    val used = total - free
    val frac = (used.toFloat() / total).coerceIn(0.02f, 1f)
    val recent = remember(nav.tick) { Fs.recent() }
    val tiles = listOf(
        Tile(Icons.Default.PhotoCamera, Color(0xFF4A6CF7), S(R.string.s089)) { nav.goDir(File(Fs.root, "DCIM")) },
        Tile(Icons.Default.Movie, Color(0xFFFF5C8A), S(R.string.s002)) { nav.goDir(File(Fs.root, "Movies")) },
        Tile(Icons.Default.Download, Color(0xFF2FA8D8), S(R.string.s090)) { nav.goDir(File(Fs.root, "Download")) },
        Tile(Icons.Default.Photo, Color(0xFF8B5CF6), S(R.string.s091)) { nav.goDir(File(Fs.root, "Pictures")) },
        Tile(Icons.Default.LibraryMusic, Color(0xFF32D2B4), S(R.string.s003)) { nav.goDir(File(Fs.root, "Music")) },
        Tile(Icons.Default.Description, Color(0xFFF2A33A), S(R.string.s004)) { nav.goDir(File(Fs.root, "Documents")) }
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 120.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(S(R.string.s092), color = p.sub, fontSize = 13.sp)
                Text(S(R.string.s093), color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            }
            NeuBtn(Icons.Default.Delete, S(R.string.s094)) { nav.tick++; nav.tab = 3 }
            Spacer(Modifier.width(12.dp))
            NeuBtn(Icons.Default.Settings, S(R.string.s095)) { nav.tab = 4 }
        }
        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp))) {
            Canvas(Modifier.matchParentSize()) {
                drawRect(Color(0xFF6A4BFF))
                val r1 = size.width * 0.7f
                drawCircle(
                    brush = Brush.radialGradient(listOf(Color(0xFFFF7AB8), Color.Transparent), center = Offset(size.width * 0.95f, 0f), radius = r1),
                    radius = r1, center = Offset(size.width * 0.95f, 0f)
                )
                val r2 = size.width * 0.55f
                drawCircle(
                    brush = Brush.radialGradient(listOf(Color(0xFF4FC3FF), Color.Transparent), center = Offset(0f, size.height), radius = r2),
                    radius = r2, center = Offset(0f, size.height)
                )
            }
            Row(
                Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.14f))
                    .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(30.dp)).padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(S(R.string.s096), color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    Text(Fs.fmt(used), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text(S(R.string.s097) + Fs.fmt(total), color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(S(R.string.s098) + Fs.fmt(free), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
                Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = 10.dp.toPx()
                        val tl = Offset(w / 2, w / 2)
                        val sz = Size(size.width - w, size.height - w)
                        drawArc(Color.White.copy(alpha = 0.25f), -90f, 360f, false, topLeft = tl, size = sz, style = Stroke(w, cap = StrokeCap.Round))
                        drawArc(Color.White, -90f, 360f * frac, false, topLeft = tl, size = sz, style = Stroke(w, cap = StrokeCap.Round))
                    }
                    Text("${(frac * 100).toInt()}%", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        SectionTitle(S(R.string.s099))
        tiles.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                row.forEach { t ->
                    Column(
                        Modifier.weight(1f).aspectRatio(1f).neu(p, 22.dp).clip(RoundedCornerShape(22.dp)).clickable { t.go() },
                        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(46.dp).clip(CircleShape).background(t.color.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                            Icon(t.icon, null, tint = t.color, modifier = Modifier.size(26.dp))
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(t.t, color = p.text, fontSize = 12.sp)
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 16.dp).neu(p, 22.dp).clip(RoundedCornerShape(22.dp)).clickable {
                val u = st.safUri
                if (Sh.granted()) nav.goSh(Sh.DATA)
                else if (Sh.available()) Sh.request()
                else if (Build.VERSION.SDK_INT < 33 && u != null) nav.goSaf(ctx, u)
                else if (Build.VERSION.SDK_INT < 33) onSaf()
                else nav.tab = 4
            }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF3DDC84).copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Android, null, tint = Color(0xFF3DDC84), modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Android/data", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text(
                    if (Sh.granted()) S(R.string.s100)
                    else if (Sh.available()) S(R.string.s101)
                    else if (Build.VERSION.SDK_INT < 33) (if (st.safUri != null) S(R.string.s102) else S(R.string.s103))
                    else S(R.string.s104),
                    color = p.sub, fontSize = 12.sp
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            HomeCard(Icons.Default.PieChart, Color(0xFF8B5CF6), S(R.string.s009), S(R.string.s105), Modifier.weight(1f)) { nav.tab = 5 }
            HomeCard(Icons.Default.Lock, Color(0xFFEF4444), S(R.string.s106), S(R.string.s107), Modifier.weight(1f)) { nav.tab = 6 }
        }
        val vols = remember(nav.tick) { Fs.volumes(ctx) }
        if (vols.isNotEmpty()) {
            SectionTitle(S(R.string.s108))
            vols.forEach { (label, vdir) ->
                val sfv = remember(vdir.path) { try { StatFs(vdir.path) } catch (e: Exception) { null } }
                Row(
                    Modifier.fillMaxWidth().padding(top = 12.dp).neu(p, 18.dp).clip(RoundedCornerShape(18.dp))
                        .clickable { nav.goDir(vdir) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.SdCard, null, tint = Color(0xFF2FA8D8))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(label, color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (sfv != null) Fs.fmt(sfv.availableBytes) + " / " + Fs.fmt(sfv.totalBytes) else "",
                            color = p.sub, fontSize = 12.sp
                        )
                    }
                }
            }
        }
        if (st.favs.isNotEmpty()) {
            SectionTitle(S(R.string.s109))
            st.favs.forEach { path ->
                val d = File(path)
                Row(
                    Modifier.fillMaxWidth().padding(top = 12.dp).neu(p, 18.dp).clip(RoundedCornerShape(18.dp))
                        .clickable { nav.goDir(d) }.padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Folder, null, tint = Color(0xFFF2A33A))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(d.name, color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(path.removePrefix(Fs.root.path), color = p.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { st.toggleFav(path) }) { Icon(Icons.Default.Star, null, tint = p.accent) }
                }
            }
        }
        if (recent.isNotEmpty()) {
            SectionTitle(S(R.string.s110))
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                val shown = recent.take(4)
                shown.forEach { f ->
                    Box(Modifier.weight(1f).aspectRatio(1f).neu(p, 18.dp).padding(6.dp)) {
                        Thumb(f, Modifier.fillMaxSize().clickable { nav.open(ctx, f, recent) }, px = 200, radius = 13.dp)
                    }
                }
                repeat(4 - shown.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun Crumb(text: String, last: Boolean, onClick: () -> Unit) {
    val p = LocalP.current
    Text(
        text, color = if (last) p.accent else p.sub, fontSize = 14.sp, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 10.dp)
    )
}

@Composable
fun Files(nav: Nav) {
    val p = LocalP.current
    val st = LocalSettings.current
    var menu by remember { mutableStateOf(false) }
    val inSaf = nav.saf.isNotEmpty()
    val inSh = nav.shPath != null
    val local = !inSaf && !inSh
    val listState by produceState<List<File>?>(null, nav.dir, nav.tick, st.hidden, st.sort, local) {
        if (local) {
            value = withContext(Dispatchers.IO) { Fs.list(nav.dir, st.hidden, st.sort) }
        } else {
            value = emptyList()
        }
    }
    val list = listState ?: emptyList()
    val loading = local && listState == null && !nav.searching
    val docs = remember(nav.saf, nav.tick) { if (inSaf) Fs.listDoc(nav.saf.last()) else emptyList() }
    val shList by produceState<List<ShEntry>?>(null, nav.shPath, nav.tick) {
        val sp = nav.shPath
        if (sp == null) {
            value = emptyList()
        } else {
            value = null
            value = withContext(Dispatchers.IO) { Sh.list(sp) }
        }
    }
    val found by produceState<List<File>>(emptyList(), nav.query, nav.dir, nav.searching, local, nav.searchContent) {
        val q = nav.query.trim()
        value = if (!nav.searching || q.length < 2 || !local) {
            emptyList()
        } else {
            withContext(Dispatchers.IO) {
                nav.dir.walkTopDown().maxDepth(8).onEnter { !it.name.startsWith(".") }
                    .filter { f ->
                        f != nav.dir && (
                            if (nav.searchContent) {
                                f.isFile && Fs.isText(f) && f.length() < 1_000_000L &&
                                    (try { f.readText().contains(q, ignoreCase = true) } catch (e: Exception) { false })
                            } else {
                                f.name.contains(q, ignoreCase = true)
                            }
                            )
                    }
                    .take(200).toList()
            }
        }
    }
    val shown = if (nav.searching) found else list
    SideEffect { nav.visible = shown }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (nav.searching) {
                OutlinedTextField(
                    value = nav.query, onValueChange = { nav.query = it }, singleLine = true,
                    placeholder = { Text(S(R.string.s111)) }, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { nav.searchContent = !nav.searchContent }) {
                    Text(if (nav.searchContent) S(R.string.s112) else S(R.string.s113), color = p.accent, fontSize = 12.sp)
                }
                NeuBtn(Icons.Default.Close, S(R.string.s114)) { nav.searching = false; nav.query = "" }
            } else {
                Row(
                    Modifier.weight(1f).glass(p, 22.dp).horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (inSh) {
                        val sp = nav.shPath ?: Sh.DATA
                        val parts = generateSequence(sp) { if (it == Sh.ANDROID || !it.startsWith(Sh.ANDROID)) null else it.substringBeforeLast('/') }.toList().reversed()
                        parts.forEachIndexed { i, path ->
                            Crumb(if (path == Sh.ANDROID) "Android" else path.substringAfterLast('/'), i == parts.lastIndex) { nav.shPath = path }
                            if (i < parts.lastIndex) Text("›", color = p.sub)
                        }
                    } else if (inSaf) {
                        nav.saf.forEachIndexed { i, d ->
                            Crumb(if (i == 0) "Android/data" else (d.name ?: "?"), i == nav.saf.lastIndex) { nav.saf = nav.saf.take(i + 1) }
                            if (i < nav.saf.lastIndex) Text("›", color = p.sub)
                        }
                    } else {
                        val parts = generateSequence(nav.dir) { if (it == Fs.root) null else it.parentFile }.toList().reversed()
                        parts.forEachIndexed { i, f ->
                            Crumb(if (f == Fs.root) S(R.string.s115) else f.name, i == parts.lastIndex) { nav.dir = f; nav.sel = emptySet() }
                            if (i < parts.lastIndex) Text("›", color = p.sub)
                        }
                    }
                }
                if (local) {
                    Spacer(Modifier.width(10.dp))
                    NeuBtn(Icons.Default.Search, S(R.string.s116)) { nav.searching = true }
                    Spacer(Modifier.width(10.dp))
                    Box {
                        NeuBtn(Icons.Default.Add, S(R.string.s117)) { menu = true }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text(S(R.string.s118)) }, onClick = { menu = false; nav.dialogText = ""; nav.dialog = "mkdir" })
                            DropdownMenuItem(text = { Text(S(R.string.s119)) }, onClick = { menu = false; nav.newTab() })
                        }
                    }
                }
            }
        }
        if (local && nav.tabDirs.size > 1) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                nav.tabDirs.forEachIndexed { i, d ->
                    val active = i == nav.tabIdx
                    val cur = if (active) nav.dir else d
                    Row(
                        Modifier.then(if (active) Modifier.inset(p, 16.dp) else Modifier.neu(p, 16.dp))
                            .clip(RoundedCornerShape(16.dp)).clickable { nav.switchTab(i) }
                            .padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (cur == Fs.root) S(R.string.s115) else cur.name, color = if (active) p.accent else p.text, fontSize = 13.sp, maxLines = 1)
                        Icon(Icons.Default.Close, null, tint = p.sub, modifier = Modifier.padding(start = 6.dp).size(18.dp).clickable { nav.closeTab(i) })
                    }
                }
            }
        }
        val clip = nav.clip
        if (clip != null && local) {
            Box(
                Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth().neu(p, 16.dp)
                    .clip(RoundedCornerShape(16.dp)).clickable { nav.paste() }.padding(12.dp),
                contentAlignment = Alignment.Center
            ) { Text(S(R.string.s120) + clip.first.size + ")", color = p.accent) }
        }
        if (inSh) {
            val sl = shList
            if (sl == null) {
                Box(Modifier.fillMaxSize(), Alignment.Center) { Text(S(R.string.s121), color = p.sub) }
            } else if (sl.isEmpty()) {
                Box(Modifier.fillMaxSize(), Alignment.Center) { Text(S(R.string.s122), color = p.sub) }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 110.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) { items(sl, key = { it.path }) { e -> ShRow(e, nav) } }
            }
        } else {
            val empty = if (inSaf) docs.isEmpty() else (shown.isEmpty() && !loading)
            if (empty) {
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Folder, null, tint = p.sub.copy(alpha = 0.45f), modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (nav.searching) (if (nav.query.trim().length < 2) S(R.string.s123) else S(R.string.s124)) else S(R.string.s125),
                        color = p.sub
                    )
                }
            } else if (inSaf) {
                LazyColumn(
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 110.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) { items(docs, key = { it.uri.toString() }) { d -> DocRow(d, nav) } }
            } else if (st.grid && !nav.searching) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 110.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) { items(shown, key = { it.path }) { f -> GridCell(f, shown, nav) } }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 110.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) { items(shown, key = { it.path }) { f -> FileRow(f, shown, nav) } }
            }
        }
    }

    val dlg = nav.dialog
    if (dlg != null) {
        AlertDialog(
            onDismissRequest = { nav.dialog = null },
            title = { Text(when (dlg) { "mkdir" -> S(R.string.s118); "unzip" -> S(R.string.s126); "zip" -> S(R.string.s127); "batch" -> S(R.string.s128); "wipe" -> S(R.string.s129); else -> S(R.string.s130) }) },
            text = {
                if (dlg == "unzip") Text(nav.pendingZip?.name ?: "")
                else if (dlg == "wipe") Text(S(R.string.s131))
                else OutlinedTextField(value = nav.dialogText, onValueChange = { nav.dialogText = it }, singleLine = true)
            },
            confirmButton = { TextButton(onClick = { nav.confirmDialog() }) { Text(if (dlg == "unzip") S(R.string.s024) else if (dlg == "wipe") S(R.string.s132) else S(R.string.s133)) } },
            dismissButton = { TextButton(onClick = { nav.dialog = null }) { Text(S(R.string.s134)) } }
        )
    }
    val sm = nav.shMenu
    if (sm != null) {
        AlertDialog(
            onDismissRequest = { nav.shMenu = null },
            title = { Text(sm.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    TextButton(onClick = { nav.shCopy(sm); nav.shMenu = null }) { Text(S(R.string.s135)) }
                    TextButton(onClick = { nav.shDelete(sm); nav.shMenu = null }) { Text(S(R.string.s132), color = Color(0xFFE5484D)) }
                }
            },
            confirmButton = { TextButton(onClick = { nav.shMenu = null }) { Text(S(R.string.s025)) } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ShRow(e: ShEntry, nav: Nav) {
    val p = LocalP.current
    val ctx = LocalContext.current
    val k = Fs.kindOf(e.name, e.isDir)
    Row(
        Modifier.fillMaxWidth().neu(p, 18.dp).clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = { if (e.isDir) nav.shPath = e.path else nav.shOpen(ctx, e) },
                onLongClick = { nav.shMenu = e }
            )
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)).background(tint(k)), contentAlignment = Alignment.Center) {
            Icon(kindIcon(k), null, tint = kindColor(k))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(e.name, color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (e.isDir) e.date else "${Fs.fmt(e.size)} · ${e.date}", color = p.sub, fontSize = 12.sp)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(f: File, siblings: List<File>, nav: Nav) {
    val p = LocalP.current
    val ctx = LocalContext.current
    val picked = f in nav.sel
    val cnt by produceState<Int?>(null, f.path, nav.tick) {
        value = if (f.isDirectory) withContext(Dispatchers.IO) { f.list()?.size ?: 0 } else null
    }
    Row(
        Modifier.fillMaxWidth()
            .then(if (picked) Modifier.inset(p, 18.dp) else Modifier.neu(p, 18.dp))
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = {
                    if (nav.sel.isNotEmpty()) nav.toggle(f)
                    else if (f.isDirectory) { nav.dir = f; nav.searching = false; nav.query = "" }
                    else nav.open(ctx, f, siblings)
                },
                onLongClick = { nav.toggle(f) }
            )
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(f, Modifier.size(54.dp), radius = 16.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (f.isDirectory) (cnt?.let { it.toString() + " " + S(R.string.s136) } ?: "…") else "${Fs.fmt(f.length())} · ${df.format(Date(f.lastModified()))}",
                color = p.sub, fontSize = 12.sp
            )
        }
        if (picked) Icon(Icons.Default.Check, null, tint = p.accent)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GridCell(f: File, siblings: List<File>, nav: Nav) {
    val p = LocalP.current
    val ctx = LocalContext.current
    val picked = f in nav.sel
    Column(
        Modifier.fillMaxWidth()
            .then(if (picked) Modifier.inset(p, 16.dp) else Modifier.neu(p, 16.dp))
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(
                onClick = {
                    if (nav.sel.isNotEmpty()) nav.toggle(f)
                    else if (f.isDirectory) { nav.dir = f; nav.searching = false; nav.query = "" }
                    else nav.open(ctx, f, siblings)
                },
                onLongClick = { nav.toggle(f) }
            )
            .padding(6.dp)
    ) {
        Thumb(f, Modifier.fillMaxWidth().aspectRatio(1f), px = 256, radius = 12.dp)
        Text(f.name, color = p.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp, start = 2.dp))
    }
}

@Composable
fun DocRow(d: DocumentFile, nav: Nav) {
    val p = LocalP.current
    val ctx = LocalContext.current
    val name = d.name ?: "?"
    val k = Fs.kindOf(name, d.isDirectory)
    Row(
        Modifier.fillMaxWidth().neu(p, 18.dp).clip(RoundedCornerShape(18.dp))
            .clickable { if (d.isDirectory) nav.saf = nav.saf + d else Fs.openDoc(ctx, d) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)).background(tint(k)), contentAlignment = Alignment.Center) {
            Icon(kindIcon(k), null, tint = kindColor(k))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (d.isDirectory) S(R.string.s137) else Fs.fmt(d.length()), color = p.sub, fontSize = 12.sp)
        }
    }
}

@Composable
fun TrashScreen(nav: Nav) {
    val p = LocalP.current
    val list = remember(nav.tick) { Fs.trashed() }
    var ask by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(start = 20.dp, end = 20.dp, top = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(S(R.string.s094), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            if (list.isNotEmpty()) TextButton(onClick = { ask = true }) { Text(S(R.string.s138), color = p.accent) }
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { Text(S(R.string.s139), color = p.sub) }
        } else {
            LazyColumn(contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(list, key = { it.first.path }) { (f, orig) ->
                    Row(Modifier.fillMaxWidth().neu(p, 18.dp).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Thumb(f, Modifier.size(54.dp), radius = 16.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name.substringAfter('_'), color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(Fs.fmt(Fs.size(f)), color = p.sub, fontSize = 12.sp)
                        }
                        TextButton(onClick = { Fs.restore(f, orig); nav.tick++ }) { Text(S(R.string.s140), color = p.accent) }
                    }
                }
            }
        }
    }
    if (ask) {
        AlertDialog(
            onDismissRequest = { ask = false },
            title = { Text(S(R.string.s141)) },
            text = { Text(S(R.string.s142)) },
            confirmButton = { TextButton(onClick = { Fs.emptyTrash(); ask = false; nav.tick++ }) { Text(S(R.string.s132), color = Color(0xFFE5484D)) } },
            dismissButton = { TextButton(onClick = { ask = false }) { Text(S(R.string.s134)) } }
        )
    }
}

@Composable
fun SwitchRow(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalP.current
    Row(Modifier.fillMaxWidth().neu(p, 18.dp).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = p.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = p.accent, checkedThumbColor = Color.White))
    }
}

@Composable
fun SettingsScreen(onSaf: () -> Unit) {
    val p = LocalP.current
    val st = LocalSettings.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(S(R.string.s095), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        ThemePicker()
        SwitchRow(S(R.string.s143), st.hidden) { st.putHidden(it) }
        SwitchRow(S(R.string.s144), st.grid) { st.putGrid(it) }
        Text(S(R.string.s145), color = p.sub, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(S(R.string.s146), S(R.string.s147), S(R.string.s056)).forEachIndexed { i, label ->
                Box(
                    Modifier.weight(1f).height(44.dp)
                        .then(if (st.sort == i) Modifier.inset(p, 16.dp) else Modifier.neu(p, 16.dp))
                        .clip(RoundedCornerShape(16.dp)).clickable { st.putSort(i) },
                    contentAlignment = Alignment.Center
                ) { Text(label, color = if (st.sort == i) p.accent else p.text, fontSize = 14.sp) }
            }
        }
        var chk by remember { mutableIntStateOf(0) }
        val avail = remember(chk) { Sh.available() }
        val granted = remember(chk) { Sh.granted() }
        Column(Modifier.fillMaxWidth().neu(p, 18.dp).padding(16.dp)) {
            Text(S(R.string.s148), color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text(
                if (!avail) S(R.string.s149)
                else if (!granted) S(R.string.s150)
                else S(R.string.s151),
                color = p.sub, fontSize = 13.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextButton(onClick = { chk++ }) { Text(S(R.string.s152), color = p.accent) }
                if (avail && !granted) TextButton(onClick = { Sh.request() }) { Text(S(R.string.s153), color = p.accent) }
            }
        }
        if (Build.VERSION.SDK_INT < 33) {
            Column(Modifier.fillMaxWidth().neu(p, 18.dp).padding(16.dp)) {
                Text(S(R.string.s154), color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                Text(S(R.string.s155), color = p.sub, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextButton(onClick = onSaf) { Text(if (st.safUri == null) S(R.string.s156) else S(R.string.s157), color = p.accent) }
                    if (st.safUri != null) TextButton(onClick = { st.putSafUri(null) }) { Text(S(R.string.s020), color = Color(0xFFE5484D)) }
                }
            }
        }
        UpdateCard()
        CrashCard()
        Text(S(R.string.s158) + Update.current(LocalContext.current), color = p.sub, fontSize = 12.sp)
    }
}

@Composable
fun NavBar(nav: Nav, modifier: Modifier) {
    val p = LocalP.current
    val items = listOf(
        Triple(Icons.Default.Home, S(R.string.s159), 0),
        Triple(Icons.Default.Folder, S(R.string.s160), 1),
        Triple(Icons.Default.Apps, S(R.string.s161), 2)
    )
    Row(
        modifier.fillMaxWidth(0.84f).glass(p, 34.dp).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { (ic, label, i) ->
            val on = nav.tab == i
            Column(
                Modifier.clip(RoundedCornerShape(26.dp))
                    .background(if (on) p.accent.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable { nav.tab = i }
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(ic, null, tint = if (on) p.accent else p.sub, modifier = Modifier.size(24.dp))
                Text(label, fontSize = 11.sp, color = if (on) p.accent else p.sub)
            }
        }
    }
}

@Composable
fun SelBar(nav: Nav, modifier: Modifier) {
    val p = LocalP.current
    val st = LocalSettings.current
    val ctx = LocalContext.current
    val one = if (nav.sel.size == 1) nav.sel.first() else null
    val ib = Modifier.size(44.dp)
    Row(
        modifier.fillMaxWidth(0.96f).glass(p, 30.dp).padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("${nav.sel.size}", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(start = 8.dp, end = 4.dp))
        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.selectAll() }, modifier = ib) { Icon(Icons.Default.SelectAll, S(R.string.s162), tint = p.text) }
            IconButton(onClick = { nav.clip = nav.sel.toList() to false; nav.sel = emptySet() }, modifier = ib) { Icon(Icons.Default.ContentCopy, S(R.string.s163), tint = p.text) }
            IconButton(onClick = { nav.clip = nav.sel.toList() to true; nav.sel = emptySet() }, modifier = ib) { Icon(Icons.Default.DriveFileMove, S(R.string.s164), tint = p.text) }
            IconButton(
                onClick = { nav.dialogText = if (one != null) one.nameWithoutExtension else S(R.string.s038); nav.dialog = "zip" },
                modifier = ib
            ) { Icon(Icons.Default.FolderZip, S(R.string.s165), tint = p.text) }
            if (one != null) {
                IconButton(onClick = { nav.dialogText = one.name; nav.dialog = "rename" }, modifier = ib) { Icon(Icons.Default.DriveFileRenameOutline, S(R.string.s166), tint = p.text) }
                if (one.isDirectory) {
                    IconButton(onClick = { st.toggleFav(one.path) }, modifier = ib) {
                        Icon(if (one.path in st.favs) Icons.Default.Star else Icons.Default.StarBorder, S(R.string.s109), tint = p.accent)
                    }
                } else {
                    if (Fs.isText(one)) {
                        IconButton(onClick = { nav.edit(one); nav.sel = emptySet() }, modifier = ib) { Icon(Icons.Default.Edit, S(R.string.s167), tint = p.accent) }
                    }
                    IconButton(onClick = { nav.pick = PickReq(one, false); nav.sel = emptySet() }, modifier = ib) { Icon(Icons.Default.OpenInNew, S(R.string.s047), tint = p.text) }
                    IconButton(onClick = { nav.pick = PickReq(one, true); nav.sel = emptySet() }, modifier = ib) { Icon(Icons.Default.Share, S(R.string.s046), tint = p.text) }
                }
            } else {
                IconButton(
                    onClick = { nav.dialogText = "{name}_{n}"; nav.dialog = "batch" },
                    modifier = ib
                ) { Icon(Icons.Default.FormatListNumbered, S(R.string.s168), tint = p.text) }
            }
            IconButton(onClick = { nav.toVault(ctx) }, modifier = ib) { Icon(Icons.Default.Lock, S(R.string.s169), tint = p.text) }
            IconButton(onClick = { nav.props = nav.sel.toList() }, modifier = ib) { Icon(Icons.Default.Info, S(R.string.s170), tint = p.text) }
            IconButton(onClick = { nav.dialog = "wipe" }, modifier = ib) { Icon(Icons.Default.DeleteForever, S(R.string.s171), tint = Color(0xFFE5484D)) }
        }
        IconButton(onClick = { nav.trashSel() }, modifier = ib) { Icon(Icons.Default.Delete, S(R.string.s021), tint = Color(0xFFE5484D)) }
    }
}

class AppInfo(val label: String, val pkg: String, val apk: String, val size: Long, val icon: Bitmap?)

@Composable
fun AppsScreen(nav: Nav) {
    val p = LocalP.current
    val ctx = LocalContext.current
    val apps by produceState<List<AppInfo>?>(null) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            pm.getInstalledApplications(0)
                .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                .map { ai ->
                    AppInfo(
                        pm.getApplicationLabel(ai).toString(), ai.packageName, ai.sourceDir, File(ai.sourceDir).length(),
                        try { pm.getApplicationIcon(ai).toBitmap(96, 96) } catch (e: Exception) { null }
                    )
                }
                .sortedBy { it.label.lowercase() }
        }
    }
    var picked by remember { mutableStateOf<AppInfo?>(null) }
    Column(Modifier.fillMaxSize().padding(start = 20.dp, end = 20.dp, top = 16.dp)) {
        Text(S(R.string.s161), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        val list = apps
        if (list == null) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { Text(S(R.string.s121), color = p.sub) }
        } else {
            LazyColumn(contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(list, key = { it.pkg }) { a ->
                    Row(
                        Modifier.fillMaxWidth().neu(p, 18.dp).clip(RoundedCornerShape(18.dp)).clickable { picked = a }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                            val ic = a.icon
                            if (ic != null) Image(ic.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                            else Icon(Icons.Default.Android, null, tint = Color(0xFF3DDC84))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.label, color = p.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${Fs.fmt(a.size)} · ${a.pkg}", color = p.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
    val a = picked
    if (a != null) {
        AlertDialog(
            onDismissRequest = { picked = null },
            title = { Text(a.label) },
            text = {
                Column {
                    Text("${a.pkg}\n${Fs.fmt(a.size)}", fontSize = 13.sp)
                    Row {
                        TextButton(onClick = { ctx.packageManager.getLaunchIntentForPackage(a.pkg)?.let { ctx.startActivity(it) }; picked = null }) { Text(S(R.string.s172)) }
                        TextButton(onClick = {
                            ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            picked = null
                        }) { Text(S(R.string.s173)) }
                    }
                    Row {
                        TextButton(onClick = {
                            nav.status = S(R.string.s174)
                            Thread {
                                try {
                                    val dir = File(Fs.root, "Download/APK")
                                    dir.mkdirs()
                                    File(a.apk).copyTo(Fs.unique(dir, a.label + ".apk"))
                                    nav.status = S(R.string.s175)
                                } catch (_: Exception) {
                                    nav.status = S(R.string.s176)
                                }
                                Thread.sleep(2500)
                                nav.status = null
                            }.start()
                            picked = null
                        }) { Text(S(R.string.s177)) }
                        TextButton(onClick = {
                            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            picked = null
                        }) { Text(S(R.string.s132), color = Color(0xFFE5484D)) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { picked = null }) { Text(S(R.string.s025)) } }
        )
    }
}

@Composable
fun AudioBar(nav: Nav, modifier: Modifier) {
    val p = LocalP.current
    val a = nav.audio
    LaunchedEffect(a.current) {
        while (true) {
            a.refresh()
            delay(400)
        }
    }
    Column(modifier.fillMaxWidth(0.92f).glass(p, 26.dp).padding(horizontal = 14.dp, vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MusicNote, null, tint = p.accent)
            Spacer(Modifier.width(10.dp))
            Text(a.current?.name ?: "", color = p.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            IconButton(onClick = { a.prev() }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.SkipPrevious, S(R.string.s178), tint = p.text) }
            IconButton(onClick = { a.toggle() }, modifier = Modifier.size(38.dp)) {
                Icon(if (a.playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (a.playing) S(R.string.s179) else S(R.string.s180), tint = p.accent)
            }
            IconButton(onClick = { a.next() }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.SkipNext, S(R.string.s181), tint = p.text) }
            IconButton(onClick = { a.stop() }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Close, S(R.string.s182), tint = p.sub) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(fmtTime(a.pos), color = p.sub, fontSize = 11.sp)
            Slider(
                value = a.pos.toFloat(), onValueChange = { a.seek(it.toInt()) },
                valueRange = 0f..maxOf(a.dur, 1).toFloat(),
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent),
                modifier = Modifier.weight(1f).height(24.dp).padding(horizontal = 8.dp)
            )
            Text(fmtTime(a.dur), color = p.sub, fontSize = 11.sp)
        }
    }
}

fun fmtTime(ms: Int): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}
