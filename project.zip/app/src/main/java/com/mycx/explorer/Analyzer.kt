package com.mycx.explorer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

fun kindLabel(k: Kind): String = when (k) {
    Kind.IMG -> S(R.string.s001)
    Kind.VID -> S(R.string.s002)
    Kind.AUD -> S(R.string.s003)
    Kind.DOC -> S(R.string.s004)
    Kind.ARC -> S(R.string.s005)
    Kind.CODE -> S(R.string.s006)
    Kind.DIR -> S(R.string.s007)
    Kind.OTHER -> S(R.string.s008)
}

@Composable
fun AnRow(f: File, checked: Boolean, nav: Nav, onToggle: () -> Unit) {
    val p = LocalP.current
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().neu(p, 16.dp).clip(RoundedCornerShape(16.dp)).clickable { onToggle() }.padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(f, Modifier.size(48.dp).clickable { nav.open(ctx, f, listOf(f)) }, px = 120, radius = 12.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = p.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                (f.parent ?: "").removePrefix(Fs.root.path) + " · " + (if (f.isDirectory) "" else Fs.fmt(f.length())),
                color = p.sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
    }
}

@Composable
fun AnalyzerScreen(nav: Nav) {
    val p = LocalP.current
    LaunchedEffect(Unit) { if (nav.scanRes == null && !nav.scanning) nav.startScan() }
    var section by remember { mutableIntStateOf(0) }
    var picked by remember(section, nav.scanRes) { mutableStateOf(setOf<File>()) }
    var gone by remember(nav.scanRes) { mutableStateOf(setOf<File>()) }
    val res = nav.scanRes
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(start = 20.dp, end = 20.dp, top = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(S(R.string.s009), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                NeuBtn(Icons.Default.Refresh, S(R.string.s010)) { nav.startScan() }
            }
            if (res == null) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(S(R.string.s011), color = p.text, fontSize = 16.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(S(R.string.s012) + nav.scanCount, color = p.sub, fontSize = 13.sp)
                    }
                }
            } else {
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth().height(12.dp).clip(CircleShape)) {
                    res.cat.entries.filter { it.value > 0 }.sortedByDescending { it.value }.forEach { (k, v) ->
                        Box(
                            Modifier.weight((v.toFloat() / maxOf(res.total, 1L)).coerceAtLeast(0.01f)).fillMaxHeight()
                                .background(kindColor(k))
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    res.cat.entries.filter { it.value > 0 }.sortedByDescending { it.value }.forEach { (k, v) ->
                        Text(kindLabel(k) + " " + Fs.fmt(v), color = kindColor(k), fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                val names = listOf(S(R.string.s013), S(R.string.s014), S(R.string.s015), S(R.string.s016), S(R.string.s004), S(R.string.s017))
                val counts = listOf(res.largest.size, res.dups.size, res.emptyDirs.size, res.screenshots.size, res.docs.size, res.oldDl.size)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    names.forEachIndexed { i, n ->
                        Box(
                            Modifier.then(if (section == i) Modifier.inset(p, 16.dp) else Modifier.neu(p, 16.dp))
                                .clip(RoundedCornerShape(16.dp)).clickable { section = i }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) { Text(n + " · " + counts[i], color = if (section == i) p.accent else p.text, fontSize = 13.sp) }
                    }
                }
                if (section == 1 && res.dups.isNotEmpty()) {
                    TextButton(onClick = {
                        picked = res.dups.flatMap { g -> g.drop(1) }.filter { it !in gone }.toSet()
                    }) { Text(S(R.string.s018), color = p.accent) }
                }
                LazyColumn(
                    contentPadding = PaddingValues(top = 8.dp, bottom = 170.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (section == 1) {
                        res.dups.forEachIndexed { gi, g ->
                            val vis = g.filter { it !in gone }
                            if (vis.size > 1) {
                                item(key = "h" + gi) {
                                    Text(S(R.string.s019) + (gi + 1), color = p.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                                }
                                items(vis, key = { gi.toString() + "|" + it.path }) { f ->
                                    AnRow(f, f in picked, nav) { picked = if (f in picked) picked - f else picked + f }
                                }
                            }
                        }
                    } else {
                        val list = when (section) {
                            0 -> res.largest
                            2 -> res.emptyDirs
                            3 -> res.screenshots
                            4 -> res.docs
                            else -> res.oldDl
                        }.filter { it !in gone }
                        items(list, key = { it.path }) { f ->
                            AnRow(f, f in picked, nav) { picked = if (f in picked) picked - f else picked + f }
                        }
                    }
                }
            }
        }
        if (picked.isNotEmpty()) {
            Row(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 92.dp).fillMaxWidth(0.92f)
                    .glass(p, 26.dp).padding(start = 16.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    picked.size.toString() + " · " + Fs.fmt(picked.sumOf { if (it.isFile) it.length() else 0L }),
                    color = p.text, fontSize = 14.sp, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { picked = emptySet() }) { Text(S(R.string.s020), color = p.sub) }
                TextButton(onClick = {
                    val list = picked.toList()
                    nav.trashFiles(list)
                    gone = gone + picked
                    picked = emptySet()
                }) { Text(S(R.string.s021), color = Color(0xFFE5484D), fontWeight = FontWeight.Bold) }
            }
        }
    }
}
