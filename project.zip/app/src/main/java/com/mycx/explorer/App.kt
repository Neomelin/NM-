package com.mycx.explorer

import android.app.Application
import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object App {
    lateinit var ctx: Context
    fun logFile(): File = File(ctx.filesDir, "crash.log")
}

fun S(id: Int, vararg a: Any): String =
    if (a.isEmpty()) App.ctx.getString(id) else App.ctx.getString(id, *a)

class NMApp : Application() {
    override fun onCreate() {
        super.onCreate()
        App.ctx = applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                val f = App.logFile()
                if (f.exists() && f.length() > 200_000) f.delete()
                f.appendText("=== " + stamp + " thread=" + t.name + "\n" + sw.toString() + "\n")
            } catch (_: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }
}
