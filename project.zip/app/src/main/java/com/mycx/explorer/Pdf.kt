package com.mycx.explorer

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private fun renderPage(r: PdfRenderer, i: Int): Bitmap? = try {
    synchronized(r) {
        val page = r.openPage(i)
        val w = 1080
        val h = (w.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        b.eraseColor(android.graphics.Color.WHITE)
        page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        b
    }
} catch (e: Exception) {
    null
}

@Composable
fun PdfViewer(f: File, onClose: () -> Unit) {
    val p = LocalP.current
    BackHandler(onBack = onClose)
    val renderer = remember(f.path) {
        try { PdfRenderer(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)) } catch (e: Exception) { null }
    }
    DisposableEffect(renderer) {
        onDispose { try { renderer?.close() } catch (_: Exception) { } }
    }
    Column(Modifier.fillMaxSize().background(p.bg).pointerInput(Unit) { }) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            NeuBtn(Icons.Default.Close, S(R.string.s025), onClose)
            Spacer(Modifier.width(12.dp))
            Text(f.name, color = p.text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (renderer != null) Text(renderer.pageCount.toString(), color = p.sub, fontSize = 13.sp)
        }
        if (renderer == null) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { Text(S(R.string.s088), color = p.sub) }
        } else {
            LazyColumn(
                Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(renderer.pageCount) { i ->
                    val bmp by produceState<Bitmap?>(null, i) { value = withContext(Dispatchers.IO) { renderPage(renderer, i) } }
                    val b = bmp
                    if (b != null) {
                        Image(
                            b.asImageBitmap(), null,
                            Modifier.fillMaxWidth().aspectRatio(b.width.toFloat() / b.height.toFloat()).clip(RoundedCornerShape(6.dp)),
                            contentScale = ContentScale.FillWidth
                        )
                    } else {
                        Box(Modifier.fillMaxWidth().aspectRatio(0.72f).clip(RoundedCornerShape(6.dp)).background(Color.White.copy(alpha = 0.6f)))
                    }
                }
            }
        }
    }
}
