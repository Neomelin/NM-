package com.mycx.explorer

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

object Syntax {
    private val kw = setOf(
        "def", "class", "return", "if", "elif", "else", "for", "while", "in", "not", "and", "or", "import", "from", "as",
        "try", "except", "finally", "with", "pass", "break", "continue", "lambda", "None", "True", "False", "self", "yield",
        "raise", "global", "nonlocal", "is", "async", "await", "del", "assert",
        "fun", "val", "var", "object", "interface", "override", "private", "public", "protected", "static", "final", "void",
        "int", "function", "const", "let", "new", "this", "package", "when", "null", "true", "false", "catch", "throw"
    )

    fun highlight(t: String, hash: Boolean, dark: Boolean): AnnotatedString {
        val cKw = if (dark) Color(0xFFC792EA) else Color(0xFF7B3FC4)
        val cStr = if (dark) Color(0xFFA5E075) else Color(0xFF2E7D32)
        val cCom = if (dark) Color(0xFF7F8794) else Color(0xFF8A94A6)
        val cNum = if (dark) Color(0xFFF2A33A) else Color(0xFFC2570C)
        val cDec = if (dark) Color(0xFFE5C07B) else Color(0xFFB08A00)
        val cDef = if (dark) Color(0xFF61AFEF) else Color(0xFF1E6FD9)
        val spans = ArrayList<Triple<Int, Int, Color>>()
        val n = t.length
        var i = 0
        while (i < n) {
            val c = t[i]
            if (hash && c == '#') {
                val e = t.indexOf('\n', i).let { if (it < 0) n else it }
                spans.add(Triple(i, e, cCom))
                i = e
            } else if (!hash && c == '/' && i + 1 < n && t[i + 1] == '/') {
                val e = t.indexOf('\n', i).let { if (it < 0) n else it }
                spans.add(Triple(i, e, cCom))
                i = e
            } else if (!hash && c == '/' && i + 1 < n && t[i + 1] == '*') {
                val e = t.indexOf("*/", i + 2).let { if (it < 0) n else it + 2 }
                spans.add(Triple(i, e, cCom))
                i = e
            } else if (c == '"' || c == '\'') {
                val triple = i + 2 < n && t[i + 1] == c && t[i + 2] == c
                var j: Int
                if (triple) {
                    val q = "" + c + c + c
                    val e = t.indexOf(q, i + 3)
                    j = if (e < 0) n else e + 3
                } else {
                    j = i + 1
                    while (j < n && t[j] != c && t[j] != '\n') {
                        if (t[j] == '\\' && j + 1 < n) j++
                        j++
                    }
                    if (j < n && t[j] == c) j++
                }
                spans.add(Triple(i, j, cStr))
                i = j
            } else if (c.isDigit()) {
                var j = i
                while (j < n && (t[j].isLetterOrDigit() || t[j] == '.')) j++
                spans.add(Triple(i, j, cNum))
                i = j
            } else if (hash && c == '@') {
                var j = i + 1
                while (j < n && (t[j].isLetterOrDigit() || t[j] == '_' || t[j] == '.')) j++
                spans.add(Triple(i, j, cDec))
                i = j
            } else if (c.isLetter() || c == '_') {
                var j = i
                while (j < n && (t[j].isLetterOrDigit() || t[j] == '_')) j++
                val w = t.substring(i, j)
                if (w in kw) {
                    spans.add(Triple(i, j, cKw))
                } else if (j < n && t[j] == '(') {
                    spans.add(Triple(i, j, cDef))
                }
                i = j
            } else {
                i++
            }
        }
        return buildAnnotatedString {
            append(t)
            spans.forEach { (s, e, col) -> addStyle(SpanStyle(color = col), s, e) }
        }
    }
}

class SyntaxTransformation(private val hash: Boolean, private val dark: Boolean) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText =
        TransformedText(Syntax.highlight(text.text, hash, dark), OffsetMapping.Identity)
}

@Composable
fun UndoToast(nav: Nav, modifier: Modifier) {
    val p = LocalP.current
    val items = nav.undo ?: return
    LaunchedEffect(nav.undoKey) {
        delay(5000)
        nav.undo = null
    }
    var dx by remember(nav.undoKey) { mutableFloatStateOf(0f) }
    Row(
        modifier.offset { IntOffset(dx.roundToInt(), 0) }.fillMaxWidth(0.92f).glass(p, 26.dp)
            .pointerInput(nav.undoKey) {
                detectHorizontalDragGestures(
                    onDragEnd = { if (abs(dx) > 120f) nav.undo = null else dx = 0f },
                    onHorizontalDrag = { _, d -> dx += d }
                )
            }
            .padding(start = 18.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(S(R.string.s044) + items.size, color = p.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = { nav.undoTrash() }) { Text(S(R.string.s045), color = p.accent, fontWeight = FontWeight.Bold) }
    }
}

class AppOpt(val label: String, val pkg: String, val cls: String, val icon: Bitmap?)

object Pick {
    private fun baseIntent(ctx: Context, f: File, send: Boolean): Intent {
        val uri = Fs.uriOf(ctx, f)
        val mime = Fs.mimeOf(f)
        return if (send) Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri)
        else Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
    }

    fun resolve(ctx: Context, f: File, send: Boolean): List<AppOpt> {
        val pm = ctx.packageManager
        val intent = baseIntent(ctx, f, send)
        val all = pm.queryIntentActivities(intent, 0).filter { it.activityInfo.packageName != ctx.packageName }
        val messenger = f.extension.lowercase() == "plugin"
        val picked = if (messenger) all.filter {
            val k = it.activityInfo.packageName.lowercase()
            k.contains("telegram") || k.contains("gram") || k.contains("nekox")
        } else all
        val use = if (picked.isEmpty()) all else picked
        return use.map { ri ->
            AppOpt(
                ri.loadLabel(pm).toString(), ri.activityInfo.packageName, ri.activityInfo.name,
                try { ri.loadIcon(pm).toBitmap(96, 96) } catch (e: Exception) { null }
            )
        }.distinctBy { it.pkg + "/" + it.cls }.sortedBy { it.label.lowercase() }
    }

    fun launch(ctx: Context, f: File, send: Boolean, o: AppOpt) {
        try {
            val i = baseIntent(ctx, f, send)
            i.setClassName(o.pkg, o.cls)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (_: Exception) { }
    }
}

@Composable
fun SharePanel(nav: Nav, req: PickReq) {
    val p = LocalP.current
    val ctx = LocalContext.current
    val apps by produceState<List<AppOpt>?>(null, req.file.path, req.send) {
        value = withContext(Dispatchers.IO) { Pick.resolve(ctx, req.file, req.send) }
    }
    BackHandler { nav.pick = null }
    val none = remember { MutableInteractionSource() }
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f))
            .clickable(interactionSource = none, indication = null) { nav.pick = null }
    ) {
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).background(p.bg)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .padding(18.dp)
        ) {
            Text(if (req.send) S(R.string.s046) else S(R.string.s047), color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(req.file.name, color = p.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(12.dp))
            val list = apps
            if (list == null) {
                Text(S(R.string.s048), color = p.sub, modifier = Modifier.padding(vertical = 24.dp))
            } else if (list.isEmpty()) {
                Text(S(R.string.s049), color = p.sub, modifier = Modifier.padding(vertical = 24.dp))
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(list, key = { it.pkg + "/" + it.cls }) { a ->
                        Column(
                            Modifier.clip(RoundedCornerShape(16.dp))
                                .clickable { Pick.launch(ctx, req.file, req.send, a); nav.pick = null }
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val ic = a.icon
                            if (ic != null) Image(ic.asImageBitmap(), null, Modifier.size(48.dp))
                            else Icon(Icons.Default.Android, null, tint = Color(0xFF3DDC84), modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(4.dp))
                            Text(a.label, color = p.text, fontSize = 11.sp, maxLines = 2, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            TextButton(onClick = {
                if (req.send) Fs.share(ctx, req.file) else Fs.openWith(ctx, req.file)
                nav.pick = null
            }) { Text(S(R.string.s050), color = p.accent) }
        }
    }
}

@Composable
fun PropRow(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 14.sp)
    }
}

@Composable
fun PropsDialog(nav: Nav, files: List<File>) {
    val df = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()) }
    val scope = rememberCoroutineScope()
    var hashTxt by remember { mutableStateOf<String?>(null) }
    val stat by produceState<Pair<Long, Int>?>(null, files) {
        value = withContext(Dispatchers.IO) {
            var size = 0L
            var cnt = 0
            files.forEach { f ->
                if (f.isDirectory) {
                    f.walkTopDown().forEach { x ->
                        if (x.isFile) size += x.length()
                        if (x != f) cnt++
                    }
                } else {
                    size += f.length()
                    cnt++
                }
            }
            size to cnt
        }
    }
    val one = if (files.size == 1) files[0] else null
    AlertDialog(
        onDismissRequest = { nav.props = null },
        title = { Text(if (one != null) one.name else S(R.string.s051) + files.size, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (one != null) {
                    PropRow(S(R.string.s052), if (one.isDirectory) S(R.string.s053) else one.extension.uppercase().ifEmpty { S(R.string.s054) })
                    PropRow(S(R.string.s055), one.parent ?: "")
                }
                PropRow(S(R.string.s056), stat?.let { Fs.fmt(it.first) } ?: S(R.string.s057))
                if (one == null || one.isDirectory) {
                    PropRow(if (one == null) S(R.string.s058) else S(R.string.s059), stat?.second?.toString() ?: "…")
                }
                if (one != null) {
                    PropRow(S(R.string.s060), df.format(Date(one.lastModified())))
                    val acc = listOf(
                        if (one.canRead()) S(R.string.s061) else "",
                        if (one.canWrite()) S(R.string.s062) else "",
                        if (one.canExecute()) S(R.string.s063) else ""
                    ).filter { it.isNotEmpty() }.joinToString(", ")
                    PropRow(S(R.string.s064), acc.ifEmpty { S(R.string.s065) })
                    PropRow(S(R.string.s066), if (one.name.startsWith(".")) S(R.string.s067) else S(R.string.s065))
                    if (!one.isDirectory) {
                        TextButton(onClick = {
                            scope.launch {
                                hashTxt = "…"
                                hashTxt = withContext(Dispatchers.IO) {
                                    "MD5: " + Fs.hash(one, "MD5") + "\nSHA-256: " + Fs.hash(one, "SHA-256")
                                }
                            }
                        }) { Text(S(R.string.s068)) }
                        val ht = hashTxt
                        if (ht != null) SelectionContainer { Text(ht, fontSize = 11.sp) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { nav.props = null }) { Text(S(R.string.s025)) } }
    )
}

@Composable
fun MiniScreen(q: P, modifier: Modifier) {
    Column(modifier.background(q.bg).padding(6.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.fillMaxWidth().height(22.dp).clip(RoundedCornerShape(6.dp)).background(q.accent))
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(2) {
                Box(
                    Modifier.weight(1f).height(18.dp).clip(RoundedCornerShape(5.dp)).background(q.card)
                        .border(0.5.dp, q.hi, RoundedCornerShape(5.dp))
                )
            }
        }
        Box(Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(3.dp)).background(q.text.copy(alpha = 0.25f)))
        Box(Modifier.fillMaxWidth(0.6f).height(7.dp).clip(RoundedCornerShape(3.dp)).background(q.text.copy(alpha = 0.25f)))
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.align(Alignment.CenterHorizontally).width(34.dp).height(8.dp)
                .clip(CircleShape).background(q.accent.copy(alpha = 0.45f))
        )
    }
}

@Composable
fun ThemeThumb(label: String, mode: Int, accent: Int, sys: Boolean, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalP.current
    val shape = RoundedCornerShape(14.dp)
    Column(modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.62f).clip(shape)
                .border(if (selected) 2.dp else 1.dp, if (selected) p.accent else p.sub.copy(alpha = 0.4f), shape)
        ) {
            if (mode == 3) {
                Row(Modifier.fillMaxSize()) {
                    MiniScreen(makeP(0, accent, sys), Modifier.weight(1f).fillMaxHeight())
                    MiniScreen(makeP(1, accent, sys), Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                MiniScreen(makeP(mode, accent, sys), Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 11.sp, color = if (selected) p.accent else p.sub)
    }
}

@Composable
fun ThemePicker() {
    val p = LocalP.current
    val st = LocalSettings.current
    val sys = isSystemInDarkTheme()
    Column(Modifier.fillMaxWidth().neu(p, 18.dp).padding(16.dp)) {
        Text(S(R.string.s069), color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(S(R.string.s070) to 0, S(R.string.s071) to 1, "AMOLED" to 2, S(R.string.s072) to 3).forEach { (label, mode) ->
                ThemeThumb(label, mode, st.accent, sys, st.theme == mode, Modifier.weight(1f)) { st.putTheme(mode) }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(S(R.string.s073), color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ACCENTS.forEachIndexed { i, c ->
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(c).clickable { st.putAccent(i) },
                    contentAlignment = Alignment.Center
                ) {
                    if (st.accent == i) Icon(Icons.Default.Check, null, tint = Color.White)
                }
            }
        }
    }
}
