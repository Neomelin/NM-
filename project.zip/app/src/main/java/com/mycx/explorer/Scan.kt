package com.mycx.explorer

import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

class ScanResult(
    val cat: Map<Kind, Long>,
    val total: Long,
    val count: Int,
    val largest: List<File>,
    val dups: List<List<File>>,
    val emptyDirs: List<File>,
    val screenshots: List<File>,
    val docs: List<File>,
    val oldDl: List<File>
)

object Scan {
    private fun sig(f: File): String? = try {
        val md = MessageDigest.getInstance("MD5")
        RandomAccessFile(f, "r").use { r ->
            val buf = ByteArray(65536)
            val n = r.read(buf)
            if (n > 0) md.update(buf, 0, n)
            val len = r.length()
            if (len > 131072) {
                r.seek(len - 65536)
                val m = r.read(buf)
                if (m > 0) md.update(buf, 0, m)
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        null
    }

    fun scan(root: File, progress: (Int) -> Unit): ScanResult {
        val cat = HashMap<Kind, Long>()
        val big = ArrayList<File>()
        val bySize = HashMap<Long, ArrayList<File>>()
        val empties = ArrayList<File>()
        val shots = ArrayList<File>()
        val docs = ArrayList<File>()
        val old = ArrayList<File>()
        val monthAgo = System.currentTimeMillis() - 30L * 24L * 3600L * 1000L
        val stack = ArrayDeque<File>()
        stack.add(root)
        var count = 0
        var total = 0L
        while (stack.isNotEmpty()) {
            val d = stack.removeLast()
            val kids = d.listFiles() ?: continue
            if (kids.isEmpty() && d != root) empties.add(d)
            for (k in kids) {
                if (k.name == ".ExplorerTrash") continue
                if (k.isDirectory) {
                    if (d == root && k.name == "Android") continue
                    if (java.nio.file.Files.isSymbolicLink(k.toPath())) continue
                    stack.add(k)
                } else {
                    val size = k.length()
                    val kind = Fs.kind(k)
                    cat[kind] = (cat[kind] ?: 0L) + size
                    total += size
                    count++
                    if (count % 500 == 0) progress(count)
                    if (size >= 1_000_000L) big.add(k)
                    if (size >= 50_000L) bySize.getOrPut(size) { ArrayList() }.add(k)
                    if (kind == Kind.IMG && (k.parentFile?.name ?: "").contains("Screenshot", ignoreCase = true)) shots.add(k)
                    if (kind == Kind.DOC) docs.add(k)
                    if (k.path.contains("/Download/") && k.lastModified() < monthAgo) old.add(k)
                }
            }
        }
        progress(count)
        val dups = ArrayList<List<File>>()
        for ((_, list) in bySize) {
            if (list.size < 2) continue
            val g = HashMap<String, ArrayList<File>>()
            for (f in list) {
                val s = sig(f) ?: continue
                g.getOrPut(s) { ArrayList() }.add(f)
            }
            for ((_, l) in g) {
                if (l.size >= 2) dups.add(l.sortedBy { it.lastModified() })
            }
        }
        dups.sortByDescending { it[0].length() * it.size }
        return ScanResult(
            cat, total, count,
            big.sortedByDescending { it.length() }.take(100),
            dups.take(200),
            empties.take(500),
            shots.sortedByDescending { it.lastModified() }.take(500),
            docs.sortedByDescending { it.lastModified() }.take(500),
            old.sortedBy { it.lastModified() }.take(500)
        )
    }
}
