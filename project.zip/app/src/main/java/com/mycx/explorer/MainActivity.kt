package com.mycx.explorer

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date

private val Bg = Color(0xFF0E1116)
private val Panel = Color(0xFF171C24)
private val Mint = Color(0xFF7CF0C9)
private val Dim = Color(0xFF8A94A6)
private val Red = Color(0xFFFF8A80)

class MainActivity : ComponentActivity() {
    private val access = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Bg, surface = Panel)) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    if (access.value) Main() else Gate { requestAccess() }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        access.value = hasAccess()
    }

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            requestPermissions(arrayOf(
                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        access.value = hasAccess()
    }
}

@Composable
fun Gate(onGrant: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🗂", fontSize = 64.sp)
        Spacer(Modifier.height(16.dp))
        Text("Нужен доступ к файлам", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Без него проводник не увидит память телефона", color = Dim)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onGrant, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Bg)) { Text("Дать доступ") }
    }
}

@Composable
fun Main() {
    var tab by remember { mutableIntStateOf(0) }
    var dir by remember { mutableStateOf(Fs.root) }
    var sel by remember { mutableStateOf(setOf<File>()) }
    var tick by remember { mutableIntStateOf(0) }

    BackHandler(enabled = sel.isNotEmpty() || tab != 0) {
        when {
            sel.isNotEmpty() -> sel = emptySet()
            tab == 1 && dir != Fs.root -> dir = dir.parentFile ?: Fs.root
            else -> tab = 0
        }
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> Home { d -> d.mkdirs(); dir = d; sel = emptySet(); tab = 1 }
                1 -> Files(dir, sel, tick, onDir = { dir = it; sel = emptySet() }, onSel = { sel = it }, onTrash = {
                    sel.forEach { Fs.toTrash(it) }; sel = emptySet(); tick++
                })
                else -> TrashScreen(tick) { tick++ }
            }
        }
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp)) {
            listOf("🏠" to "Главная", "🗂" to "Файлы", "🗑" to "Корзина").forEachIndexed { i, (e, n) ->
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                        .background(if (tab == i) Color(0x227CF0C9) else Color.Transparent)
                        .clickable { tab = i; if (i == 2) tick++ }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(e, fontSize = 20.sp)
                    Text(n, fontSize = 12.sp, color = if (tab == i) Mint else Dim)
                }
            }
        }
    }
}

@Composable
fun Ring(frac: Float, modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier) {
        val w = 16.dp.toPx()
        val tl = Offset(w / 2, w / 2)
        val sz = Size(size.width - w, size.height - w)
        drawArc(Color(0xFF252C38), 0f, 360f, false, topLeft = tl, size = sz, style = Stroke(w, cap = StrokeCap.Round))
        drawArc(Mint, -90f, 360f * frac, false, topLeft = tl, size = sz, style = Stroke(w, cap = StrokeCap.Round))
    }
}

@Composable
fun Home(onDir: (File) -> Unit) {
    val sf = remember { StatFs(Fs.root.path) }
    val total = sf.totalBytes
    val free = sf.availableBytes
    val used = total - free
    val cats = listOf(
        Triple("⬇️", "Загрузки", "Download"), Triple("📷", "Камера", "DCIM"),
        Triple("🖼", "Картинки", "Pictures"), Triple("🎵", "Музыка", "Music"),
        Triple("🎬", "Видео", "Movies"), Triple("📄", "Документы", "Documents"))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Проводник", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Panel).padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(110.dp), contentAlignment = Alignment.Center) {
                Ring(used.toFloat() / total, Modifier.fillMaxSize())
                Text("${used * 100 / total}%", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(20.dp))
            Column {
                Text("Занято ${Fs.fmt(used)}", color = Color.White, fontSize = 17.sp)
                Text("из ${Fs.fmt(total)}", color = Dim)
                Spacer(Modifier.height(6.dp))
                Text("Свободно ${Fs.fmt(free)}", color = Mint)
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("Быстрый доступ", color = Dim)
        cats.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (e, n, path) ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(Panel)
                        .clickable { onDir(File(Fs.root, path)) }.padding(18.dp)) {
                        Text(e, fontSize = 30.sp)
                        Spacer(Modifier.height(10.dp))
                        Text(n, color = Color.White, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Files(dir: File, sel: Set<File>, tick: Int, onDir: (File) -> Unit, onSel: (Set<File>) -> Unit, onTrash: () -> Unit) {
    val ctx = LocalContext.current
    val list = remember(dir, tick) { Fs.list(dir) }
    val fmtDate = remember { SimpleDateFormat("dd.MM.yy HH:mm") }
    Column(Modifier.fillMaxSize()) {
        if (sel.isEmpty()) {
            val parts = generateSequence(dir) { if (it == Fs.root) null else it.parentFile }.toList().reversed()
            Row(Modifier.fillMaxWidth().background(Panel).horizontalScroll(rememberScrollState()).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                parts.forEachIndexed { i, f ->
                    Text(if (f == Fs.root) "Память" else f.name, color = if (i == parts.lastIndex) Mint else Dim,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { onDir(f) }.padding(8.dp))
                    if (i < parts.lastIndex) Text("›", color = Dim)
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Выбрано: ${sel.size}", color = Color.White, modifier = Modifier.weight(1f))
                TextButton(onClick = onTrash) { Text("В корзину", color = Red) }
                TextButton(onClick = { onSel(emptySet()) }) { Text("Отмена", color = Dim) }
            }
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Пусто", color = Dim) }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.path }) { f ->
                    val picked = f in sel
                    val toggle = { onSel(if (picked) sel - f else sel + f) }
                    Row(
                        Modifier.fillMaxWidth()
                            .combinedClickable(
                                onClick = {
                                    when {
                                        sel.isNotEmpty() -> toggle()
                                        f.isDirectory -> onDir(f)
                                        else -> Fs.open(ctx, f)
                                    }
                                },
                                onLongClick = { toggle() })
                            .background(if (picked) Color(0x227CF0C9) else Color.Transparent)
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Panel), contentAlignment = Alignment.Center) {
                            Text(Fs.icon(f), fontSize = 22.sp)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (f.isDirectory) "${f.listFiles()?.size ?: 0} объектов"
                                else "${Fs.fmt(f.length())} • ${fmtDate.format(Date(f.lastModified()))}",
                                color = Dim, fontSize = 13.sp)
                        }
                        if (picked) Text("✓", color = Mint, fontSize = 20.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun TrashScreen(tick: Int, onChange: () -> Unit) {
    val list = remember(tick) { Fs.trashed() }
    var ask by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Корзина", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (list.isNotEmpty()) TextButton(onClick = { ask = true }) { Text("Очистить", color = Mint) }
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Корзина пуста", color = Dim) }
        } else {
            LazyColumn {
                items(list, key = { it.first.path }) { (f, orig) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(Fs.icon(f), fontSize = 24.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name.substringAfter('_'), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(Fs.fmt(Fs.size(f)), color = Dim, fontSize = 13.sp)
                        }
                        TextButton(onClick = { Fs.restore(f, orig); onChange() }) { Text("Вернуть", color = Mint) }
                    }
                }
            }
        }
    }
    if (ask) AlertDialog(
        onDismissRequest = { ask = false },
        title = { Text("Очистить корзину?") },
        text = { Text("Файлы будут удалены навсегда.") },
        confirmButton = { TextButton(onClick = { Fs.emptyTrash(); ask = false; onChange() }) { Text("Удалить", color = Red) } },
        dismissButton = { TextButton(onClick = { ask = false }) { Text("Отмена") } })
}
