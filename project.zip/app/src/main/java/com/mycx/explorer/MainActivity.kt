package com.mycx.explorer

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {
    private val access = mutableStateOf(false)
    private lateinit var settings: AppSettings

    private val safLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) { }
            settings.putSafUri(uri.toString())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = AppSettings(getSharedPreferences("nm", MODE_PRIVATE))
        setContent {
            val p = if (settings.dark) DarkP else LightP
            CompositionLocalProvider(LocalP provides p, LocalSettings provides settings) {
                MaterialTheme(
                    colorScheme = if (settings.dark) darkColorScheme(primary = p.accent) else lightColorScheme(primary = p.accent)
                ) {
                    Surface(Modifier.fillMaxSize(), color = p.bg) {
                        if (access.value) Main { requestSaf() } else Gate { requestAccess() }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        access.value = hasAccess()
    }

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            requestPermissions(
                arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 1
            )
        }
    }

    private fun requestSaf() {
        safLauncher.launch(DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:Android/data"))
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        access.value = hasAccess()
    }
}

@Composable
fun Gate(onGrant: () -> Unit) {
    val p = LocalP.current
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Folder, null, tint = p.accent, modifier = Modifier.size(72.dp))
        Spacer(Modifier.height(16.dp))
        Text("Нужен доступ к файлам", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Без него проводник не увидит память телефона", color = p.sub)
        Spacer(Modifier.height(24.dp))
        Box(
            Modifier.neu(p, 22.dp).clip(RoundedCornerShape(22.dp)).clickable(onClick = onGrant).padding(horizontal = 28.dp, vertical = 14.dp)
        ) { Text("Дать доступ", color = p.accent, fontSize = 16.sp) }
    }
}

@Composable
fun Main(onSaf: () -> Unit) {
    val nav = remember { Nav() }
    val p = LocalP.current
    val st = LocalSettings.current
    val view = LocalView.current

    SideEffect {
        val w = (view.context as Activity).window
        w.statusBarColor = p.bg.toArgb()
        w.navigationBarColor = p.bg.toArgb()
        val c = WindowCompat.getInsetsController(w, view)
        c.isAppearanceLightStatusBars = !st.dark
        c.isAppearanceLightNavigationBars = !st.dark
    }

    BackHandler(enabled = nav.sel.isNotEmpty() || nav.tab != 0) {
        when {
            nav.sel.isNotEmpty() -> nav.sel = emptySet()
            nav.tab == 1 && nav.shPath != null -> nav.shUp()
            nav.tab == 1 && nav.saf.size > 1 -> nav.saf = nav.saf.dropLast(1)
            nav.tab == 1 && nav.saf.size == 1 -> { nav.saf = emptyList(); nav.tab = 0 }
            nav.tab == 1 && nav.dir != Fs.root -> nav.dir = nav.dir.parentFile ?: Fs.root
            else -> nav.tab = 0
        }
    }

    Box(Modifier.fillMaxSize().background(p.bg)) {
        when (nav.tab) {
            0 -> Home(nav, onSaf)
            1 -> Files(nav)
            2 -> AppsScreen(nav)
            3 -> TrashScreen(nav)
            else -> SettingsScreen(onSaf)
        }
        if (nav.audio.current != null && nav.viewer == null) {
            AudioBar(nav, Modifier.align(Alignment.BottomCenter).padding(bottom = 80.dp))
        }
        if (nav.tab == 1 && nav.sel.isNotEmpty()) {
            SelBar(nav, Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp))
        } else {
            NavBar(nav, Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp))
        }
        nav.viewer?.let { Viewer(it) { nav.viewer = null } }
        nav.textFile?.let { TextViewer(it) { nav.textFile = null } }
        nav.status?.let { msg ->
            Box(Modifier.align(Alignment.TopCenter).padding(top = 12.dp).glass(p, 20.dp).padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(msg, color = p.text, fontSize = 13.sp)
            }
        }
    }
}
