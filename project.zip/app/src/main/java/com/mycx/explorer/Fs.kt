package com.mycx.explorer

import android.content.Context
import android.content.Intent
import android.os.Environment
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import java.io.File

enum class Kind { DIR, IMG, VID, AUD, ARC, CODE, DOC, OTHER }

object Fs {
    val root: File get() = Environment.getExternalStorageDirectory()
    val trash: File get() = File(root, ".ExplorerTrash").also { it.mkdirs() }
    private val index: File get() = File(trash, ".index")

    fun kindOf(name: String, isDir: Boolean): Kind = if (isDir) Kind.DIR else when (name.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic" -> Kind.IMG
        "mp4", "mkv", "webm", "avi", "3gp", "mov" -> Kind.VID
        "mp3", "flac", "ogg", "wav", "m4a", "aac" -> Kind.AUD
        "zip", "rar", "7z", "apk", "mcaddon", "tar", "gz" -> Kind.ARC
        "plugin", "py", "kt", "java", "js", "json", "html", "xml", "sh" -> Kind.CODE
        "txt", "pdf", "doc", "docx", "xls", "xlsx", "md" -> Kind.DOC
        else -> Kind.OTHER
    }

    fun kind(f: File): Kind = kindOf(f.name, f.isDirectory)

    fun opensAsText(f: File): Boolean = isText(f) && f.extension.lowercase() != "plugin"

    fun isText(f: File): Boolean =
        f.extension.lowercase() in setOf("txt", "md", "json", "py", "kt", "java", "js", "html", "xml", "sh", "plugin", "log", "csv", "conf", "ini", "yml", "yaml", "properties", "gradle", "kts") &&
            f.length() < 3_000_000

    fun glyph(k: Kind): String = when (k) {
        Kind.DIR -> "📁"
        Kind.IMG -> "🖼"
        Kind.VID -> "🎬"
        Kind.AUD -> "🎵"
        Kind.ARC -> "📦"
        Kind.CODE -> "🧩"
        Kind.DOC -> "📄"
        Kind.OTHER -> "📎"
    }

    fun list(dir: File, showHidden: Boolean, sort: Int): List<File> {
        val all = (dir.listFiles()?.toList() ?: emptyList()).filter { showHidden || !it.name.startsWith(".") }
        val cmp: Comparator<File> = when (sort) {
            1 -> compareByDescending<File> { it.lastModified() }
            2 -> compareByDescending<File> { if (it.isDirectory) 0L else it.length() }
            else -> compareBy<File> { it.name.lowercase() }
        }
        return all.sortedWith(compareByDescending<File> { it.isDirectory }.then(cmp))
    }

    fun recent(): List<File> =
        listOf("DCIM/Camera", "Download", "Pictures", "Movies", "DCIM")
            .flatMap { File(root, it).listFiles()?.toList() ?: emptyList() }
            .filter { it.isFile && !it.name.startsWith(".") }
            .distinct()
            .sortedByDescending { it.lastModified() }
            .take(8)

    fun unique(dir: File, name: String): File {
        var f = File(dir, name)
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var i = 1
        while (f.exists()) {
            f = File(dir, if (ext.isEmpty()) "$name ($i)" else "$base ($i).$ext")
            i++
        }
        return f
    }

    fun toTrash(f: File): Pair<File, String>? {
        val name = "${System.currentTimeMillis()}_${f.name}"
        val dst = File(trash, name)
        return if (f.renameTo(dst)) {
            index.appendText("$name\t${f.absolutePath}\n")
            dst to f.absolutePath
        } else {
            null
        }
    }

    fun trashed(): List<Pair<File, String>> {
        val map = if (index.exists())
            index.readLines().mapNotNull { l -> l.split("\t").takeIf { it.size == 2 }?.let { it[0] to it[1] } }.toMap()
        else emptyMap()
        return (trash.listFiles()?.toList() ?: emptyList())
            .filter { !it.name.startsWith(".") }
            .map { it to (map[it.name] ?: File(root, "Download/" + it.name.substringAfter('_')).absolutePath) }
    }

    fun restore(f: File, orig: String) {
        var target = File(orig)
        target.parentFile?.mkdirs()
        if (target.exists()) target = File(target.parentFile, "restored_" + target.name)
        f.renameTo(target)
        if (index.exists()) index.writeText(index.readLines().filter { !it.startsWith(f.name + "\t") }.joinToString("\n") + "\n")
    }

    fun emptyTrash() { trash.listFiles()?.forEach { it.deleteRecursively() } }

    fun size(f: File): Long = if (f.isDirectory) f.walkTopDown().filter { it.isFile }.sumOf { it.length() } else f.length()

    fun fmt(b: Long): String {
        if (b < 1024) return "$b Б"
        val u = listOf("КБ", "МБ", "ГБ")
        var v = b / 1024.0
        var i = 0
        while (v >= 1024 && i < 2) { v /= 1024; i++ }
        return "%.1f %s".format(v, u[i])
    }

    fun mimeOf(f: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"

    fun uriOf(ctx: Context, f: File) = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fp", f)

    private fun viewIntent(ctx: Context, f: File): Intent =
        Intent(Intent.ACTION_VIEW).setDataAndType(uriOf(ctx, f), mimeOf(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)

    fun open(ctx: Context, f: File) {
        if (f.extension.lowercase() == "plugin") { openWith(ctx, f); return }
        try {
            ctx.startActivity(viewIntent(ctx, f))
        } catch (_: Exception) {
            share(ctx, f)
        }
    }

    fun openWith(ctx: Context, f: File) {
        try {
            ctx.startActivity(
                Intent.createChooser(viewIntent(ctx, f), f.name)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) { }
    }

    fun share(ctx: Context, f: File) {
        try {
            val i = Intent(Intent.ACTION_SEND).setType(mimeOf(f))
                .putExtra(Intent.EXTRA_STREAM, uriOf(ctx, f))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(
                Intent.createChooser(i, f.name)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) { }
    }

    fun listDoc(d: DocumentFile): List<DocumentFile> =
        d.listFiles().toList().sortedWith(compareByDescending<DocumentFile> { it.isDirectory }.thenBy { (it.name ?: "").lowercase() })

    fun openDoc(ctx: Context, d: DocumentFile) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(d.uri, d.type ?: "*/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) { }
    }
}
