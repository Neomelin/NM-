package com.mycx.explorer

import android.content.Context
import android.content.Intent
import android.os.Environment
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File

object Fs {
    val root: File get() = Environment.getExternalStorageDirectory()
    val trash: File get() = File(root, ".ExplorerTrash").also { it.mkdirs() }
    private val index: File get() = File(trash, ".index")

    fun list(dir: File): List<File> =
        (dir.listFiles()?.toList() ?: emptyList())
            .filter { !it.name.startsWith(".") }
            .sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })

    fun toTrash(f: File) {
        val name = "${System.currentTimeMillis()}_${f.name}"
        if (f.renameTo(File(trash, name))) index.appendText("$name\t${f.absolutePath}\n")
    }

    fun trashed(): List<Pair<File, String>> {
        val map = if (index.exists())
            index.readLines().mapNotNull { l -> l.split("\t").takeIf { it.size == 2 }?.let { it[0] to it[1] } }.toMap()
        else emptyMap()
        return (trash.listFiles()?.toList() ?: emptyList())
            .filter { !it.name.startsWith(".") }
            .map { it to (map[it.name] ?: File(root, "Download/" + it.name.substringAfter('_')).absolutePath) }
    }

    fun restore(f: File, orig: String) {
        var target = File(orig)
        target.parentFile?.mkdirs()
        if (target.exists()) target = File(target.parentFile, "restored_" + target.name)
        f.renameTo(target)
        if (index.exists()) index.writeText(index.readLines().filter { !it.startsWith(f.name + "\t") }.joinToString("\n") + "\n")
    }

    fun emptyTrash() { trash.listFiles()?.forEach { it.deleteRecursively() } }

    fun size(f: File): Long = if (f.isDirectory) f.walkTopDown().filter { it.isFile }.sumOf { it.length() } else f.length()

    fun fmt(b: Long): String {
        if (b < 1024) return "$b Б"
        val u = listOf("КБ", "МБ", "ГБ")
        var v = b / 1024.0
        var i = 0
        while (v >= 1024 && i < 2) { v /= 1024; i++ }
        return "%.1f %s".format(v, u[i])
    }

    fun icon(f: File): String = if (f.isDirectory) "📁" else when (f.extension.lowercase()) {
        "jpg", "jpeg", "png", "webp", "gif" -> "🖼"
        "mp4", "mkv", "webm", "avi" -> "🎬"
        "mp3", "flac", "ogg", "wav", "m4a" -> "🎵"
        "zip", "rar", "7z", "apk", "mcaddon" -> "📦"
        "plugin", "py", "kt", "html", "js", "json" -> "🧩"
        else -> "📄"
    }

    fun open(ctx: Context, f: File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fp", f)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) { }
    }
}
