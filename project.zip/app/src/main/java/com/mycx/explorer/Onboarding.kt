package com.mycx.explorer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.launch

@Composable
fun OnbPage(icon: ImageVector, title: String, text: String) {
    val p = LocalP.current
    Column(
        Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(120.dp).neu(p, 60.dp), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = p.accent, modifier = Modifier.size(56.dp))
        }
        Spacer(Modifier.height(32.dp))
        Text(title, color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(text, color = p.sub, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun Onboarding() {
    val p = LocalP.current
    val st = LocalSettings.current
    val state = rememberPagerState { 3 }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        HorizontalPager(state, Modifier.weight(1f).fillMaxWidth()) { page ->
            when (page) {
                0 -> OnbPage(
                    Icons.Default.Folder, S(R.string.s081),
                    S(R.string.s082)
                )
                1 -> OnbPage(
                    Icons.Default.Lock, S(R.string.s083),
                    S(R.string.s084)
                )
                else -> Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(S(R.string.s085), color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    ThemePicker()
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalArrangement = Arrangement.Center) {
            repeat(3) { i ->
                val on = i == state.currentPage
                Box(
                    Modifier.padding(horizontal = 4.dp).size(width = if (on) 22.dp else 8.dp, height = 8.dp)
                        .clip(CircleShape).background(if (on) p.accent else p.sub.copy(alpha = 0.4f))
                )
            }
        }
        Box(
            Modifier.fillMaxWidth().neu(p, 22.dp).clip(RoundedCornerShape(22.dp)).clickable {
                if (state.currentPage < 2) scope.launch { state.animateScrollToPage(state.currentPage + 1) }
                else st.putOnboarded()
            }.padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(if (state.currentPage < 2) S(R.string.s086) else S(R.string.s087), color = p.accent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
