package com.mycx.explorer

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.File

class ShEntry(val name: String, val path: String, val isDir: Boolean, val size: Long, val date: String)

object Sh {
    const val ANDROID = "/storage/emulated/0/Android"
    const val DATA = "/storage/emulated/0/Android/data"

    fun available(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        available() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun request() {
        try { Shizuku.requestPermission(1001) } catch (_: Throwable) { }
    }

    private fun start(cmd: Array<String>): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, cmd, null, null) as Process
    }

    private fun run(vararg cmd: String): String? = try {
        val p = start(arrayOf(*cmd))
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Throwable) {
        null
    }

    private fun ok(vararg cmd: String): Boolean = try {
        val p = start(arrayOf(*cmd))
        p.inputStream.readBytes()
        p.waitFor() == 0
    } catch (e: Throwable) {
        false
    }

    fun list(path: String): List<ShEntry> {
        val out = run("ls", "-lA", path) ?: return emptyList()
        val sep = Regex("\\s+")
        val res = ArrayList<ShEntry>()
        for (line in out.lineSequence()) {
            val l = line.trim()
            if (l.isEmpty() || l.startsWith("total")) continue
            val t = l.split(sep, 8)
            if (t.size < 8) continue
            val name = t[7].substringBefore(" -> ")
            val dir = t[0].startsWith("d") || t[0].startsWith("l")
            res.add(ShEntry(name, "$path/$name", dir, t[4].toLongOrNull() ?: 0L, t[5] + " " + t[6]))
        }
        return res.sortedWith(compareByDescending<ShEntry> { it.isDir }.thenBy { it.name.lowercase() })
    }

    fun pull(path: String, dst: File): Boolean = try {
        dst.parentFile?.mkdirs()
        val p = start(arrayOf("cat", path))
        p.inputStream.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        p.waitFor() == 0
    } catch (e: Throwable) {
        false
    }

    fun copyToDownload(path: String): Boolean = ok("cp", "-r", path, "/storage/emulated/0/Download/")

    fun delete(path: String): Boolean = ok("rm", "-rf", path)
}
