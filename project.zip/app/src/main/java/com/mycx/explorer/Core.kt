package com.mycx.explorer

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipInputStream

class P(val bg: Color, val hi: Color, val lo: Color, val text: Color, val sub: Color, val accent: Color, val dark: Boolean)

val LightP = P(Color(0xFFE0E5EC), Color(0xFFFFFFFF), Color(0xFFA3B1C6), Color(0xFF4A5570), Color(0xFF6B7A99), Color(0xFF4A6CF7), false)
val DarkP = P(Color(0xFF22262F), Color(0xFF2C313D), Color(0xFF181B21), Color(0xFFE6E9F2), Color(0xFF8A93A8), Color(0xFF6C8CFF), true)

val LocalP = staticCompositionLocalOf { LightP }
val LocalSettings = staticCompositionLocalOf<AppSettings> { error("AppSettings not provided") }

class AppSettings(private val sp: SharedPreferences) {
    var dark by mutableStateOf(sp.getBoolean("dark", false))
        private set
    var hidden by mutableStateOf(sp.getBoolean("hidden", false))
        private set
    var sort by mutableIntStateOf(sp.getInt("sort", 0))
        private set
    var grid by mutableStateOf(sp.getBoolean("grid", false))
        private set
    var safUri by mutableStateOf<String?>(sp.getString("saf", null))
        private set

    fun putDark(v: Boolean) { dark = v; sp.edit().putBoolean("dark", v).apply() }
    fun putHidden(v: Boolean) { hidden = v; sp.edit().putBoolean("hidden", v).apply() }
    fun putSort(v: Int) { sort = v; sp.edit().putInt("sort", v).apply() }
    fun putGrid(v: Boolean) { grid = v; sp.edit().putBoolean("grid", v).apply() }
    fun putSafUri(v: String?) { safUri = v; sp.edit().putString("saf", v).apply() }
}

class ViewerReq(val files: List<File>, val index: Int)

class AudioPlayer {
    private var mp: MediaPlayer? = null
    var current by mutableStateOf<File?>(null)
        private set
    var playing by mutableStateOf(false)
        private set

    fun play(f: File) {
        stop()
        try {
            val m = MediaPlayer()
            m.setDataSource(f.path)
            m.setOnCompletionListener { playing = false }
            m.prepare()
            m.start()
            mp = m
            current = f
            playing = true
        } catch (_: Exception) {
            stop()
        }
    }

    fun toggle() {
        val m = mp ?: return
        if (m.isPlaying) { m.pause(); playing = false } else { m.start(); playing = true }
    }

    fun stop() {
        try { mp?.release() } catch (_: Exception) { }
        mp = null
        current = null
        playing = false
    }
}

class Nav {
    var tab by mutableIntStateOf(0)
    var dir by mutableStateOf(Fs.root)
    var saf by mutableStateOf<List<DocumentFile>>(emptyList())
    var sel by mutableStateOf(setOf<File>())
    var tick by mutableIntStateOf(0)
    var clip by mutableStateOf<Pair<List<File>, Boolean>?>(null)
    var viewer by mutableStateOf<ViewerReq?>(null)
    var dialog by mutableStateOf<String?>(null)
    var dialogText by mutableStateOf("")
    val audio = AudioPlayer()
    var textFile by mutableStateOf<File?>(null)
    var textEdit by mutableStateOf(false)
    var searching by mutableStateOf(false)
    var query by mutableStateOf("")
    var status by mutableStateOf<String?>(null)
    var pendingZip by mutableStateOf<File?>(null)
    var shPath by mutableStateOf<String?>(null)
    var shMenu by mutableStateOf<ShEntry?>(null)
    var tabDirs by mutableStateOf(listOf(Fs.root))
    var tabIdx by mutableIntStateOf(0)

    fun edit(f: File) { textEdit = true; textFile = f }

    fun toggle(f: File) { sel = if (f in sel) sel - f else sel + f }

    fun goDir(d: File) { d.mkdirs(); dir = d; saf = emptyList(); shPath = null; sel = emptySet(); tab = 1 }

    fun goSaf(ctx: Context, uri: String) {
        val d = DocumentFile.fromTreeUri(ctx, Uri.parse(uri))
        if (d != null) { saf = listOf(d); shPath = null; sel = emptySet(); tab = 1 }
    }

    fun open(ctx: Context, f: File, siblings: List<File>) {
        when (Fs.kind(f)) {
            Kind.IMG -> {
                val imgs = siblings.filter { Fs.kind(it) == Kind.IMG }
                viewer = ViewerReq(imgs, imgs.indexOf(f).coerceAtLeast(0))
            }
            Kind.VID -> viewer = ViewerReq(listOf(f), 0)
            Kind.AUD -> audio.play(f)
            Kind.ARC -> if (f.extension.lowercase() == "zip") { pendingZip = f; dialog = "unzip" } else Fs.open(ctx, f)
            else -> if (Fs.opensAsText(f)) { textEdit = false; textFile = f } else Fs.open(ctx, f)
        }
    }

    fun paste() {
        val c = clip ?: return
        c.first.forEach { src ->
            try {
                if (dir == src || dir.path.startsWith(src.path + "/")) return@forEach
                val dst = Fs.unique(dir, src.name)
                if (c.second) {
                    if (!src.renameTo(dst)) { src.copyRecursively(dst); src.deleteRecursively() }
                } else {
                    src.copyRecursively(dst)
                }
            } catch (_: Exception) { }
        }
        clip = null
        tick++
    }

    fun goSh(path: String) { shPath = path; saf = emptyList(); sel = emptySet(); searching = false; tab = 1 }

    fun shUp() {
        val sp = shPath ?: return
        if (sp == Sh.ANDROID || !sp.startsWith(Sh.ANDROID)) { shPath = null; tab = 0 } else shPath = sp.substringBeforeLast('/')
    }

    fun shOpen(ctx: Context, e: ShEntry) {
        status = "Открываю…"
        Thread {
            val dst = File(ctx.cacheDir, "sh/" + e.name)
            if (Sh.pull(e.path, dst)) {
                Handler(Looper.getMainLooper()).post { status = null; open(ctx, dst, listOf(dst)) }
            } else {
                status = "Не удалось открыть"
                Thread.sleep(2500)
                status = null
            }
        }.start()
    }

    fun shCopy(e: ShEntry) {
        status = "Копирую…"
        Thread {
            status = if (Sh.copyToDownload(e.path)) "Скопировано в Download" else "Не удалось скопировать"
            Thread.sleep(2500)
            status = null
        }.start()
    }

    fun shDelete(e: ShEntry) {
        status = "Удаляю…"
        Thread {
            status = if (Sh.delete(e.path)) "Удалено" else "Не удалось удалить"
            tick++
            Thread.sleep(2500)
            status = null
        }.start()
    }

    fun newTab() {
        val l = tabDirs.toMutableList()
        l[tabIdx] = dir
        l.add(dir)
        tabDirs = l
        tabIdx = l.lastIndex
    }

    fun switchTab(i: Int) {
        if (i == tabIdx || i !in tabDirs.indices) return
        val l = tabDirs.toMutableList()
        l[tabIdx] = dir
        tabDirs = l
        tabIdx = i
        dir = l[i]
        sel = emptySet()
        searching = false
    }

    fun closeTab(i: Int) {
        if (tabDirs.size <= 1 || i !in tabDirs.indices) return
        val l = tabDirs.toMutableList()
        l[tabIdx] = dir
        l.removeAt(i)
        val ni = when {
            i < tabIdx -> tabIdx - 1
            i == tabIdx -> minOf(i, l.lastIndex)
            else -> tabIdx
        }
        tabDirs = l
        tabIdx = ni
        dir = l[ni]
        sel = emptySet()
    }

    fun trashSel() { sel.forEach { Fs.toTrash(it) }; sel = emptySet(); tick++ }

    fun unzip(src: File) {
        status = "Распаковка…"
        Thread {
            try {
                val parent = src.parentFile ?: Fs.root
                val dst = Fs.unique(parent, src.nameWithoutExtension)
                dst.mkdirs()
                val base = dst.canonicalPath + File.separator
                ZipInputStream(src.inputStream().buffered()).use { zin ->
                    var e = zin.nextEntry
                    while (e != null) {
                        val out = File(dst, e.name)
                        if (out.canonicalPath.startsWith(base)) {
                            if (e.isDirectory) {
                                out.mkdirs()
                            } else {
                                out.parentFile?.mkdirs()
                                out.outputStream().use { o -> zin.copyTo(o) }
                            }
                        }
                        zin.closeEntry()
                        e = zin.nextEntry
                    }
                }
                status = "Готово: ${dst.name}"
            } catch (_: Exception) {
                status = "Не удалось распаковать"
            }
            tick++
            Thread.sleep(2500)
            status = null
        }.start()
    }

    fun confirmDialog() {
        if (dialog == "unzip") {
            pendingZip?.let { unzip(it) }
            pendingZip = null
            dialog = null
            return
        }
        val name = dialogText.trim()
        if (name.isNotEmpty()) {
            try {
                if (dialog == "mkdir") File(dir, name).mkdirs()
                else sel.firstOrNull()?.let { it.renameTo(File(it.parentFile, name)) }
            } catch (_: Exception) { }
            sel = emptySet()
            tick++
        }
        dialog = null
    }
}

fun Modifier.neu(p: P, r: Dp = 20.dp): Modifier = this.drawBehind {
    val rad = r.toPx()
    val off = 5.dp.toPx()
    val step = 1.6.dp.toPx()
    for (i in 7 downTo 1) {
        val g = i * step
        val sz = Size(size.width + g * 2, size.height + g * 2)
        drawRoundRect(p.lo.copy(alpha = 0.12f), topLeft = Offset(off - g, off - g), size = sz, cornerRadius = CornerRadius(rad + g))
        drawRoundRect(p.hi.copy(alpha = 0.12f), topLeft = Offset(-off - g, -off - g), size = sz, cornerRadius = CornerRadius(rad + g))
    }
    drawRoundRect(p.bg, cornerRadius = CornerRadius(rad))
}

fun Modifier.inset(p: P, r: Dp = 20.dp): Modifier {
    val s = RoundedCornerShape(r)
    return this.clip(s)
        .background(lerp(p.bg, p.lo, 0.18f))
        .border(1.5.dp, Brush.linearGradient(listOf(p.lo, p.hi)), s)
}

fun Modifier.glass(p: P, r: Dp = 26.dp): Modifier {
    val s = RoundedCornerShape(r)
    return this.clip(s)
        .background(if (p.dark) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.45f))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.8f), Color.White.copy(alpha = 0.15f))), s)
}

fun tint(k: Kind): Color = when (k) {
    Kind.DIR -> Color(0x40F2A33A)
    Kind.IMG -> Color(0x404A6CF7)
    Kind.VID -> Color(0x40FF5C8A)
    Kind.AUD -> Color(0x4032D2B4)
    Kind.ARC -> Color(0x40B08A3A)
    Kind.CODE -> Color(0x408B5CF6)
    Kind.DOC -> Color(0x4060A5FA)
    Kind.OTHER -> Color(0x308A93A8)
}

fun kindIcon(k: Kind): ImageVector = when (k) {
    Kind.DIR -> Icons.Default.Folder
    Kind.IMG -> Icons.Default.Photo
    Kind.VID -> Icons.Default.Videocam
    Kind.AUD -> Icons.Default.MusicNote
    Kind.ARC -> Icons.Default.FolderZip
    Kind.CODE -> Icons.Default.Code
    Kind.DOC -> Icons.Default.Description
    Kind.OTHER -> Icons.Default.InsertDriveFile
}

fun kindColor(k: Kind): Color = when (k) {
    Kind.DIR -> Color(0xFFF2A33A)
    Kind.IMG -> Color(0xFF4A6CF7)
    Kind.VID -> Color(0xFFFF5C8A)
    Kind.AUD -> Color(0xFF32D2B4)
    Kind.ARC -> Color(0xFFB08A3A)
    Kind.CODE -> Color(0xFF8B5CF6)
    Kind.DOC -> Color(0xFF60A5FA)
    Kind.OTHER -> Color(0xFF8A93A8)
}

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(((Runtime.getRuntime().maxMemory() / 8) / 1024).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun load(f: File, px: Int): Bitmap? {
        val key = "${f.path}|${f.lastModified()}|$px"
        cache.get(key)?.let { return it }
        val bmp: Bitmap? = when (Fs.kind(f)) {
            Kind.IMG -> decode(f, px)
            Kind.VID -> {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(f.path)
                    r.getScaledFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, px, px)
                } catch (e: Exception) {
                    null
                } finally {
                    r.release()
                }
            }
            else -> null
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }

    fun full(f: File): Bitmap? = decode(f, 2048)

    private fun decode(f: File, px: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= px && o.outHeight / (s * 2) >= px) s *= 2
        BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (e: Throwable) {
        null
    }
}

@Composable
fun Thumb(f: File, modifier: Modifier, px: Int = 160, radius: Dp = 14.dp) {
    val kind = Fs.kind(f)
    val bmp by produceState<Bitmap?>(null, f.path, px) {
        value = if (kind == Kind.IMG || kind == Kind.VID) withContext(Dispatchers.IO) { Thumbs.load(f, px) } else null
    }
    Box(modifier.clip(RoundedCornerShape(radius)).background(tint(kind)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(kindIcon(kind), null, tint = kindColor(kind), modifier = Modifier.size(28.dp))
        }
        if (kind == Kind.VID && b != null) {
            Box(Modifier.size(26.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}
