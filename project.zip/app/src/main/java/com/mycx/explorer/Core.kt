package com.mycx.explorer

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.crypto.spec.SecretKeySpec
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class P(
    val bg: Color, val card: Color, val hi: Color, val lo: Color,
    val text: Color, val sub: Color, val accent: Color, val dark: Boolean
)

val ACCENTS = listOf(
    Color(0xFF4A6CF7), Color(0xFF8B5CF6), Color(0xFFEC4899), Color(0xFFEF4444),
    Color(0xFFF59E0B), Color(0xFF22C55E), Color(0xFF14B8A6), Color(0xFF0EA5E9)
)

fun makeP(theme: Int, accent: Int, systemDark: Boolean): P {
    val a = ACCENTS[accent.coerceIn(0, ACCENTS.lastIndex)]
    val mode = if (theme == 3) (if (systemDark) 1 else 0) else theme
    return when (mode) {
        1 -> P(Color(0xFF22262F), Color(0xFF22262F), Color(0xFF2C313D), Color(0xFF181B21), Color(0xFFE6E9F2), Color(0xFF8A93A8), a, true)
        2 -> P(Color(0xFF000000), Color(0xFF0E0F12), Color(0xFF24262C), Color(0xFF000000), Color(0xFFEDEFF5), Color(0xFF8A8F9C), a, true)
        else -> P(Color(0xFFE0E5EC), Color(0xFFE0E5EC), Color(0xFFFFFFFF), Color(0xFFA3B1C6), Color(0xFF4A5570), Color(0xFF6B7A99), a, false)
    }
}

val LightP = makeP(0, 0, false)

val LocalP = staticCompositionLocalOf { LightP }
val LocalSettings = staticCompositionLocalOf<AppSettings> { error("AppSettings not provided") }

class AppSettings(private val sp: SharedPreferences) {
    var theme by mutableIntStateOf(sp.getInt("theme", if (sp.getBoolean("dark", false)) 1 else 0))
        private set
    var accent by mutableIntStateOf(sp.getInt("accent", 0))
        private set
    var favs by mutableStateOf(sp.getStringSet("favs", emptySet())?.toList()?.sorted() ?: emptyList())
        private set
    var hidden by mutableStateOf(sp.getBoolean("hidden", false))
        private set
    var sort by mutableIntStateOf(sp.getInt("sort", 0))
        private set
    var grid by mutableStateOf(sp.getBoolean("grid", false))
        private set
    var safUri by mutableStateOf<String?>(sp.getString("saf", null))
        private set

    var onboarded by mutableStateOf(sp.getBoolean("onb", false))
        private set

    fun putOnboarded() { onboarded = true; sp.edit().putBoolean("onb", true).apply() }

    fun putTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun putAccent(v: Int) { accent = v; sp.edit().putInt("accent", v).apply() }
    fun toggleFav(path: String) {
        favs = if (path in favs) favs - path else (favs + path).sorted()
        sp.edit().putStringSet("favs", favs.toSet()).apply()
    }
    fun putHidden(v: Boolean) { hidden = v; sp.edit().putBoolean("hidden", v).apply() }
    fun putSort(v: Int) { sort = v; sp.edit().putInt("sort", v).apply() }
    fun putGrid(v: Boolean) { grid = v; sp.edit().putBoolean("grid", v).apply() }
    fun putSafUri(v: String?) { safUri = v; sp.edit().putString("saf", v).apply() }
}

class ViewerReq(val files: List<File>, val index: Int)

class PickReq(val file: File, val send: Boolean)

class AudioPlayer {
    private var mp: MediaPlayer? = null
    private var queue: List<File> = emptyList()
    var current by mutableStateOf<File?>(null)
        private set
    var playing by mutableStateOf(false)
        private set
    var pos by mutableIntStateOf(0)
        private set
    var dur by mutableIntStateOf(0)
        private set

    fun play(f: File, q: List<File> = listOf(f)) {
        queue = if (q.isEmpty()) listOf(f) else q
        start(f)
    }

    private fun start(f: File) {
        release()
        try {
            val m = MediaPlayer()
            m.setDataSource(f.path)
            m.setOnCompletionListener { next() }
            m.prepare()
            m.start()
            mp = m
            current = f
            playing = true
            dur = m.duration
            pos = 0
        } catch (_: Exception) {
            stop()
        }
    }

    fun next() {
        val c = current ?: return
        val i = queue.indexOf(c)
        if (i >= 0 && i + 1 < queue.size) start(queue[i + 1]) else playing = false
    }

    fun prev() {
        val c = current ?: return
        val m = mp
        if (m != null && m.currentPosition > 3000) { m.seekTo(0); return }
        val i = queue.indexOf(c)
        if (i > 0) start(queue[i - 1]) else m?.seekTo(0)
    }

    fun seek(ms: Int) { mp?.seekTo(ms); pos = ms }

    fun refresh() {
        val m = mp ?: return
        try {
            pos = m.currentPosition
            dur = m.duration
        } catch (_: Exception) { }
    }

    fun toggle() {
        val m = mp ?: return
        if (m.isPlaying) { m.pause(); playing = false } else { m.start(); playing = true }
    }

    private fun release() {
        try { mp?.release() } catch (_: Exception) { }
        mp = null
    }

    fun stop() {
        release()
        current = null
        playing = false
        pos = 0
        dur = 0
    }
}

class Nav {
    var tab by mutableIntStateOf(0)
    var dir by mutableStateOf(Fs.root)
    var saf by mutableStateOf<List<DocumentFile>>(emptyList())
    var sel by mutableStateOf(setOf<File>())
    var tick by mutableIntStateOf(0)
    var clip by mutableStateOf<Pair<List<File>, Boolean>?>(null)
    var viewer by mutableStateOf<ViewerReq?>(null)
    var dialog by mutableStateOf<String?>(null)
    var dialogText by mutableStateOf("")
    val audio = AudioPlayer()
    var textFile by mutableStateOf<File?>(null)
    var textEdit by mutableStateOf(false)
    var searching by mutableStateOf(false)
    var query by mutableStateOf("")
    var status by mutableStateOf<String?>(null)
    var pendingZip by mutableStateOf<File?>(null)
    var shPath by mutableStateOf<String?>(null)
    var shMenu by mutableStateOf<ShEntry?>(null)
    var tabDirs by mutableStateOf(listOf(Fs.root))
    var tabIdx by mutableIntStateOf(0)
    var undo by mutableStateOf<List<Pair<File, String>>?>(null)
    var undoKey by mutableIntStateOf(0)
    var pick by mutableStateOf<PickReq?>(null)
    var props by mutableStateOf<List<File>?>(null)
    var visible: List<File> = emptyList()
    var scanRes by mutableStateOf<ScanResult?>(null)
    var scanning by mutableStateOf(false)
    var scanCount by mutableIntStateOf(0)
    var vaultKey by mutableStateOf<SecretKeySpec?>(null)
    var pendingVault by mutableStateOf<List<File>>(emptyList())
    var arcFile by mutableStateOf<File?>(null)
    var pdfFile by mutableStateOf<File?>(null)
    var searchContent by mutableStateOf(false)

    fun edit(f: File) { textEdit = true; textFile = f }

    fun toggle(f: File) { sel = if (f in sel) sel - f else sel + f }

    fun goDir(d: File) { d.mkdirs(); dir = d; saf = emptyList(); shPath = null; sel = emptySet(); tab = 1 }

    fun goSaf(ctx: Context, uri: String) {
        val d = DocumentFile.fromTreeUri(ctx, Uri.parse(uri))
        if (d != null) { saf = listOf(d); shPath = null; sel = emptySet(); tab = 1 }
    }

    fun open(ctx: Context, f: File, siblings: List<File>) {
        when (Fs.kind(f)) {
            Kind.IMG -> {
                val imgs = siblings.filter { Fs.kind(it) == Kind.IMG }
                viewer = ViewerReq(imgs, imgs.indexOf(f).coerceAtLeast(0))
            }
            Kind.VID -> viewer = ViewerReq(listOf(f), 0)
            Kind.AUD -> audio.play(f, siblings.filter { Fs.kind(it) == Kind.AUD })
            Kind.ARC -> if (Arc.supported(f)) arcFile = f else Fs.open(ctx, f)
            else -> {
                if (f.extension.equals("pdf", ignoreCase = true)) pdfFile = f
                else if (Fs.opensAsText(f)) { textEdit = false; textFile = f }
                else if (f.extension.lowercase() == "plugin") pick = PickReq(f, false)
                else Fs.open(ctx, f)
            }
        }
    }

    fun paste() {
        val c = clip ?: return
        c.first.forEach { src ->
            try {
                if (dir == src || dir.path.startsWith(src.path + "/")) return@forEach
                val dst = Fs.unique(dir, src.name)
                if (c.second) {
                    if (!src.renameTo(dst)) { src.copyRecursively(dst); src.deleteRecursively() }
                } else {
                    src.copyRecursively(dst)
                }
            } catch (_: Exception) { }
        }
        clip = null
        tick++
    }

    fun goSh(path: String) { shPath = path; saf = emptyList(); sel = emptySet(); searching = false; tab = 1 }

    fun shUp() {
        val sp = shPath ?: return
        if (sp == Sh.ANDROID || !sp.startsWith(Sh.ANDROID)) { shPath = null; tab = 0 } else shPath = sp.substringBeforeLast('/')
    }

    fun shOpen(ctx: Context, e: ShEntry) {
        status = S(R.string.s026)
        Thread {
            val dst = File(ctx.cacheDir, "sh/" + e.name)
            if (Sh.pull(e.path, dst)) {
                Handler(Looper.getMainLooper()).post { status = null; open(ctx, dst, listOf(dst)) }
            } else {
                status = S(R.string.s027)
                Thread.sleep(2500)
                status = null
            }
        }.start()
    }

    fun shCopy(e: ShEntry) {
        status = S(R.string.s028)
        Thread {
            status = if (Sh.copyToDownload(e.path)) S(R.string.s029) else S(R.string.s030)
            Thread.sleep(2500)
            status = null
        }.start()
    }

    fun shDelete(e: ShEntry) {
        status = S(R.string.s031)
        Thread {
            status = if (Sh.delete(e.path)) S(R.string.s032) else S(R.string.s033)
            tick++
            Thread.sleep(2500)
            status = null
        }.start()
    }

    fun newTab() {
        val l = tabDirs.toMutableList()
        l[tabIdx] = dir
        l.add(dir)
        tabDirs = l
        tabIdx = l.lastIndex
    }

    fun switchTab(i: Int) {
        if (i == tabIdx || i !in tabDirs.indices) return
        val l = tabDirs.toMutableList()
        l[tabIdx] = dir
        tabDirs = l
        tabIdx = i
        dir = l[i]
        sel = emptySet()
        searching = false
    }

    fun closeTab(i: Int) {
        if (tabDirs.size <= 1 || i !in tabDirs.indices) return
        val l = tabDirs.toMutableList()
        l[tabIdx] = dir
        l.removeAt(i)
        val ni = when {
            i < tabIdx -> tabIdx - 1
            i == tabIdx -> minOf(i, l.lastIndex)
            else -> tabIdx
        }
        tabDirs = l
        tabIdx = ni
        dir = l[ni]
        sel = emptySet()
    }

    fun flash(msg: String) {
        status = msg
        Thread {
            Thread.sleep(2500)
            if (status == msg) status = null
        }.start()
    }

    fun trashFiles(list: List<File>) {
        val done = list.mapNotNull { Fs.toTrash(it) }
        tick++
        if (done.isNotEmpty()) { undo = done; undoKey++ }
    }

    fun startScan() {
        if (scanning) return
        scanning = true
        scanCount = 0
        scanRes = null
        Thread {
            try {
                scanRes = Scan.scan(Fs.root) { n -> scanCount = n }
            } catch (_: Throwable) {
                scanRes = ScanResult(emptyMap(), 0L, 0, emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList())
            }
            scanning = false
        }.start()
    }

    fun lockVault(ctx: Context) {
        vaultKey = null
        try { File(ctx.cacheDir, "vault").deleteRecursively() } catch (_: Exception) { }
    }

    fun toVault(ctx: Context) {
        val files = sel.filter { it.isFile }
        sel = emptySet()
        if (files.isEmpty()) {
            flash(S(R.string.s034))
            return
        }
        if (vaultKey != null) addToVault(ctx, files) else { pendingVault = files; tab = 6 }
    }

    fun addToVault(ctx: Context, files: List<File>) {
        val k = vaultKey ?: return
        pendingVault = emptyList()
        status = S(R.string.s035)
        Thread {
            var ok = 0
            files.forEach { if (Vault.add(ctx, k, it)) ok++ }
            tick++
            flash(S(R.string.s036) + ok)
        }.start()
    }

    fun batchRename(pattern: String) {
        if (pattern.isEmpty()) return
        val items = sel.toList().sortedBy { it.name.lowercase() }
        var n = 1
        items.forEach { f ->
            val ext = if (f.isDirectory || f.extension.isEmpty()) "" else "." + f.extension
            val base = pattern.replace("{name}", f.nameWithoutExtension).replace("{n}", n.toString())
            val dst = Fs.unique(f.parentFile ?: dir, base + ext)
            if (f.renameTo(dst)) n++
        }
        sel = emptySet()
        tick++
    }

    fun wipeSel() {
        val items = sel.toList()
        sel = emptySet()
        status = S(R.string.s037)
        Thread {
            items.forEach { Fs.wipe(it) }
            tick++
            flash(S(R.string.s032))
        }.start()
    }

    fun selectAll() { sel = visible.toSet() }

    fun undoTrash() {
        undo?.forEach { (t, o) -> Fs.restore(t, o) }
        undo = null
        tick++
    }

    fun trashSel() {
        val done = sel.mapNotNull { Fs.toTrash(it) }
        sel = emptySet()
        tick++
        if (done.isNotEmpty()) { undo = done; undoKey++ }
    }

    fun zipSel(rawName: String) {
        val items = sel.toList()
        val base = dir
        val name = (if (rawName.isEmpty()) S(R.string.s038) else rawName).removeSuffix(".zip") + ".zip"
        sel = emptySet()
        status = S(R.string.s039)
        Thread {
            try {
                val out = Fs.unique(base, name)
                ZipOutputStream(out.outputStream().buffered()).use { z ->
                    items.forEach { item ->
                        val root = item.parentFile ?: base
                        val files = if (item.isDirectory) item.walkTopDown().toList() else listOf(item)
                        files.forEach { f ->
                            if (f != out) {
                                val rel = f.relativeTo(root).path.replace(File.separatorChar, '/')
                                if (f.isDirectory) {
                                    z.putNextEntry(ZipEntry("$rel/"))
                                    z.closeEntry()
                                } else {
                                    z.putNextEntry(ZipEntry(rel))
                                    f.inputStream().use { it.copyTo(z) }
                                    z.closeEntry()
                                }
                            }
                        }
                    }
                }
                status = S(R.string.s040) + out.name
            } catch (_: Exception) {
                status = S(R.string.s041)
            }
            tick++
            Thread.sleep(2500)
            status = null
        }.start()
    }

    fun unzip(src: File) {
        status = S(R.string.s042)
        Thread {
            try {
                val parent = src.parentFile ?: Fs.root
                val b = src.name.substringBeforeLast('.')
                val nm = if (b.endsWith(".tar")) b.removeSuffix(".tar") else b
                val dst = Fs.unique(parent, nm)
                Arc.extractAll(src, dst)
                status = S(R.string.s040) + dst.name
            } catch (_: Exception) {
                status = S(R.string.s043)
            }
            tick++
            Thread.sleep(2500)
            status = null
        }.start()
    }

    fun confirmDialog() {
        if (dialog == "batch") {
            batchRename(dialogText.trim())
            dialog = null
            return
        }
        if (dialog == "wipe") {
            wipeSel()
            dialog = null
            return
        }
        if (dialog == "zip") {
            zipSel(dialogText.trim())
            dialog = null
            return
        }
        if (dialog == "unzip") {
            pendingZip?.let { unzip(it) }
            pendingZip = null
            dialog = null
            return
        }
        val name = dialogText.trim()
        if (name.isNotEmpty()) {
            try {
                if (dialog == "mkdir") File(dir, name).mkdirs()
                else sel.firstOrNull()?.let { it.renameTo(File(it.parentFile, name)) }
            } catch (_: Exception) { }
            sel = emptySet()
            tick++
        }
        dialog = null
    }
}

fun Modifier.neu(p: P, r: Dp = 20.dp): Modifier = this.drawBehind {
    val rad = r.toPx()
    val off = 5.dp.toPx()
    val step = 1.6.dp.toPx()
    for (i in 7 downTo 1) {
        val g = i * step
        val sz = Size(size.width + g * 2, size.height + g * 2)
        drawRoundRect(p.lo.copy(alpha = 0.12f), topLeft = Offset(off - g, off - g), size = sz, cornerRadius = CornerRadius(rad + g))
        drawRoundRect(p.hi.copy(alpha = 0.12f), topLeft = Offset(-off - g, -off - g), size = sz, cornerRadius = CornerRadius(rad + g))
    }
    drawRoundRect(p.card, cornerRadius = CornerRadius(rad))
}

fun Modifier.inset(p: P, r: Dp = 20.dp): Modifier {
    val s = RoundedCornerShape(r)
    return this.clip(s)
        .background(lerp(p.bg, p.lo, 0.18f))
        .border(1.5.dp, Brush.linearGradient(listOf(p.lo, p.hi)), s)
}

fun Modifier.glass(p: P, r: Dp = 26.dp): Modifier {
    val s = RoundedCornerShape(r)
    return this.clip(s)
        .background(if (p.dark) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.45f))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.8f), Color.White.copy(alpha = 0.15f))), s)
}

fun tint(k: Kind): Color = when (k) {
    Kind.DIR -> Color(0x40F2A33A)
    Kind.IMG -> Color(0x404A6CF7)
    Kind.VID -> Color(0x40FF5C8A)
    Kind.AUD -> Color(0x4032D2B4)
    Kind.ARC -> Color(0x40B08A3A)
    Kind.CODE -> Color(0x408B5CF6)
    Kind.DOC -> Color(0x4060A5FA)
    Kind.OTHER -> Color(0x308A93A8)
}

fun kindIcon(k: Kind): ImageVector = when (k) {
    Kind.DIR -> Icons.Default.Folder
    Kind.IMG -> Icons.Default.Photo
    Kind.VID -> Icons.Default.Videocam
    Kind.AUD -> Icons.Default.MusicNote
    Kind.ARC -> Icons.Default.FolderZip
    Kind.CODE -> Icons.Default.Code
    Kind.DOC -> Icons.Default.Description
    Kind.OTHER -> Icons.Default.InsertDriveFile
}

fun kindColor(k: Kind): Color = when (k) {
    Kind.DIR -> Color(0xFFF2A33A)
    Kind.IMG -> Color(0xFF4A6CF7)
    Kind.VID -> Color(0xFFFF5C8A)
    Kind.AUD -> Color(0xFF32D2B4)
    Kind.ARC -> Color(0xFFB08A3A)
    Kind.CODE -> Color(0xFF8B5CF6)
    Kind.DOC -> Color(0xFF60A5FA)
    Kind.OTHER -> Color(0xFF8A93A8)
}

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(((Runtime.getRuntime().maxMemory() / 8) / 1024).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun load(f: File, px: Int): Bitmap? {
        val key = "${f.path}|${f.lastModified()}|$px"
        cache.get(key)?.let { return it }
        val bmp: Bitmap? = when (Fs.kind(f)) {
            Kind.IMG -> decode(f, px)
            Kind.VID -> {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(f.path)
                    r.getScaledFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, px, px)
                } catch (e: Exception) {
                    null
                } finally {
                    r.release()
                }
            }
            else -> null
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }

    fun full(f: File): Bitmap? = decode(f, 2048)

    private fun decode(f: File, px: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= px && o.outHeight / (s * 2) >= px) s *= 2
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        if (bmp == null) null else rotate(bmp, orientation(f))
    } catch (e: Throwable) {
        null
    }

    private fun orientation(f: File): Int = try {
        ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    } catch (e: Exception) {
        ExifInterface.ORIENTATION_NORMAL
    }

    private fun rotate(b: Bitmap, o: Int): Bitmap {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return b
        }
        return try { Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true) } catch (e: Throwable) { b }
    }
}

@Composable
fun Thumb(f: File, modifier: Modifier, px: Int = 160, radius: Dp = 14.dp) {
    val kind = Fs.kind(f)
    val bmp by produceState<Bitmap?>(null, f.path, px) {
        value = if (kind == Kind.IMG || kind == Kind.VID) withContext(Dispatchers.IO) { Thumbs.load(f, px) } else null
    }
    Box(modifier.clip(RoundedCornerShape(radius)).background(tint(kind)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(kindIcon(kind), null, tint = kindColor(kind), modifier = Modifier.size(28.dp))
        }
        if (kind == Kind.VID && b != null) {
            Box(Modifier.size(26.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}
