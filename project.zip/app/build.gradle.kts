plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
val relKs: String? = System.getenv("NM_KEYSTORE_PATH")

android {
    namespace = "com.mycx.explorer"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mycx.explorer"
        minSdk = 28
        targetSdk = 34
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1) + 100
        versionName = System.getenv("NM_VERSION") ?: "0.8"
    }
    signingConfigs {
        if (relKs != null) {
            create("release") {
                storeFile = file(relKs)
                storePassword = System.getenv("NM_STORE_PASS")
                keyAlias = System.getenv("NM_KEY_ALIAS")
                keyPassword = System.getenv("NM_KEY_PASS")
            }
        }
        create("nm") {
            storeFile = file("nm.keystore")
            storePassword = "nmexplorer"
            keyAlias = "nm"
            keyPassword = "nmexplorer"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("nm") }
        getByName("release") {
            isMinifyEnabled = false
            if (relKs != null) signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
